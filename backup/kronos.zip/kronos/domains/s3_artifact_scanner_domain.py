import abc
from enum import Enum, auto
from typing import Optional, Set, Tuple

from botocore.exceptions import ClientError

from ..conf import settings
from ..data_models.dataset_model import ArtifactsStatusEnum
from ..utils.boto3_utils import has_s3_object
from . import s3_artifact_scanner_domain_exceptions as exceptions


class ArtifactEnum(Enum):
    GPKG = auto()
    ICP_MAP_V2 = auto()
    NON_COLOR_TILES = auto()
    COLOR_TILES = auto()
    PCD = auto()
    ROAD_METRICS = auto()
    BEV = auto()
    ICP_MAP_V1 = auto()


class ArtifactRequirementEnum(Enum):
    ALL = auto()
    REQUIRED = auto()
    OPTIONAL = auto()


class AbstractArtifactScanner(abc.ABC):
    def __init__(self, region, session):
        self.region = region
        self.session = session

    @property
    @abc.abstractmethod
    def artifact_name(self):
        pass

    @property
    @abc.abstractmethod
    def bucket_name(self):
        pass

    @property
    @abc.abstractmethod
    def is_required(self):
        pass

    @abc.abstractmethod
    def get_s3_key(self):
        pass

    @property
    def has_artifact(self) -> bool:
        try:
            return has_s3_object(self.bucket_name, self.get_s3_key())
        except ClientError as exc:
            raise exceptions.BaseS3ArtifactScannerException from exc

    @staticmethod
    def make_scanner_from_enum(
        region: str, session: str, artifact_enum: ArtifactEnum
    ) -> "AbstractArtifactScanner":
        if artifact_enum == ArtifactEnum.GPKG:
            return GpkgArtifactScanner(region, session)
        elif artifact_enum == ArtifactEnum.ICP_MAP_V2:
            return IcpMapV2ArtifactScanner(region, session)
        elif artifact_enum == ArtifactEnum.NON_COLOR_TILES:
            return NonColorTilesArtifactScanner(region, session)
        elif artifact_enum == ArtifactEnum.COLOR_TILES:
            return ColorTilesArtifactScanner(region, session)
        elif artifact_enum == ArtifactEnum.PCD:
            return PcdArtifactScanner(region, session)
        elif artifact_enum == ArtifactEnum.ROAD_METRICS:
            return RoadMetricsArtifactScanner(region, session)
        elif artifact_enum == ArtifactEnum.BEV:
            return BevArtifactScanner(region, session)
        elif artifact_enum == ArtifactEnum.ICP_MAP_V1:
            return IcpMapV1ArtifactScanner(region, session)
        else:
            raise ValueError("Unrecognized ArtifactEnum")

    @staticmethod
    def make_scanners_from_requirement(
        region: str, session: str, artifact_requirement_enum: ArtifactRequirementEnum
    ) -> Set["AbstractArtifactScanner"]:
        artifact_scanners = set()
        for enum in ArtifactEnum:
            scanner = AbstractArtifactScanner.make_scanner_from_enum(
                region, session, enum
            )
            if artifact_requirement_enum == ArtifactRequirementEnum.ALL:
                artifact_scanners.add(scanner)
            elif (
                scanner.is_required
                and artifact_requirement_enum == ArtifactRequirementEnum.REQUIRED
            ):
                artifact_scanners.add(scanner)
            elif (
                not scanner.is_required
                and artifact_requirement_enum == ArtifactRequirementEnum.OPTIONAL
            ):
                artifact_scanners.add(scanner)
        return artifact_scanners

    @staticmethod
    def get_required_artifact_names() -> Set[str]:
        names = set()
        for scanner in AbstractArtifactScanner.make_scanners_from_requirement(
            "", "", ArtifactRequirementEnum.REQUIRED
        ):
            names.add(scanner.artifact_name)
        return names

    @staticmethod
    def get_number_of_required_artifacts() -> int:
        return len(AbstractArtifactScanner.get_required_artifact_names())

    @staticmethod
    def determine_artifacts_status(
        region: str,
        session: str,
        # For optimisation, only scans a subset of required artifacts to determine `artifacts_status`.
        artifact_scanners: Optional[Set["AbstractArtifactScanner"]] = None,
    ) -> Optional[str]:
        # If artifact_scanners is None, use all required artifacts.
        if artifact_scanners is None:
            artifact_scanners = AbstractArtifactScanner.make_scanners_from_requirement(
                region=region,
                session=session,
                artifact_requirement_enum=ArtifactRequirementEnum.REQUIRED,
            )

        # Collate status of all required artifacts.
        required_artifacts_statuses = [
            scanner.has_artifact for scanner in artifact_scanners if scanner.is_required
        ]
        scanned_all_required_artifacts = (
            len(required_artifacts_statuses)
            == AbstractArtifactScanner.get_number_of_required_artifacts()
        )

        # If we scanned all required artifacts, we can safely overwrite artifacts_status with GRAPH_ONLY.
        if scanned_all_required_artifacts:
            artifacts_status = ArtifactsStatusEnum.GRAPH_ONLY.value
        # If only partial scan, we cannot accurately determine if the status should be GRAPH_ONLY,
        #  so leave as None.
        else:
            artifacts_status = None

        if scanned_all_required_artifacts and all(required_artifacts_statuses):
            artifacts_status = ArtifactsStatusEnum.ALL_REQUIRED.value
        elif any(required_artifacts_statuses):
            artifacts_status = ArtifactsStatusEnum.SOME_REQUIRED.value

        return artifacts_status


class GpkgArtifactScanner(AbstractArtifactScanner):
    artifact_name = "gpkg"
    bucket_name = settings.S3_BUCKET_NAME_BASEMAPDB
    is_required = True

    def get_s3_key(self) -> str:
        return f"{self.region}/{self.session}/resources/{self.region}-{self.session}-basemap.gpkg"


class IcpMapV2ArtifactScanner(AbstractArtifactScanner):
    artifact_name = "icp_map_v2"
    bucket_name = settings.S3_BUCKET_NAME_BASEMAPDB
    is_required = True

    def get_s3_key(self) -> str:
        return f"{self.region}/{self.session}/icp-map/v2/icp.dat"


class NonColorTilesArtifactScanner(AbstractArtifactScanner):
    artifact_name = "non_color_tiles"
    bucket_name = settings.S3_BUCKET_NAME_BASEMAPTILES
    is_required = True

    def get_s3_key(self) -> Tuple[str, str]:
        return (
            f"basemaplive/{self.region}/{self.session}/intensity/0/0/0.png",
            f"basemaplive/{self.region}/{self.session}/vertical/0/0/0.png",
        )

    @property
    def has_artifact(self) -> bool:
        try:
            intensity_key, vertical_key = self.get_s3_key()
            return has_s3_object(self.bucket_name, intensity_key) and has_s3_object(
                self.bucket_name, vertical_key
            )
        except ClientError as exc:
            raise exceptions.BaseS3ArtifactScannerException from exc


class ColorTilesArtifactScanner(AbstractArtifactScanner):
    artifact_name = "color_tiles"
    bucket_name = settings.S3_BUCKET_NAME_BASEMAPTILES
    is_required = True

    def get_s3_key(self) -> str:
        return f"basemaplive/{self.region}/{self.session}/color/0/0/0.png"


class PcdArtifactScanner(AbstractArtifactScanner):
    artifact_name = "pcd"
    bucket_name = settings.S3_BUCKET_NAME_BASEMAPTILES
    is_required = True

    def get_s3_key(self) -> str:
        return f"basemaplive/{self.region}/{self.session}/pcd/tiles-metadata.json"


class RoadMetricsArtifactScanner(AbstractArtifactScanner):
    artifact_name = "road_metrics"
    bucket_name = settings.S3_BUCKET_NAME_BASEMAPTILES
    is_required = True

    def get_s3_key(self) -> str:
        return f"basemaplive/{self.region}/{self.session}/roadthickness/0/0/0.png"


class BevArtifactScanner(AbstractArtifactScanner):
    artifact_name = "bev"
    bucket_name = settings.S3_BUCKET_NAME_BASEMAPTILES
    is_required = False

    def get_s3_key(self) -> str:
        return f"basemaplive/{self.region}/{self.session}/bev/0/0/0.png"


class IcpMapV1ArtifactScanner(AbstractArtifactScanner):
    artifact_name = "icp_map_v1"
    bucket_name = settings.S3_BUCKET_NAME_BASEMAPDB
    is_required = False

    def get_s3_key(self) -> str:
        return f"{self.region}/{self.session}/icp-map/icp.dat"
