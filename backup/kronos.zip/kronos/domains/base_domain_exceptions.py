class BaseDomainsException(Exception):
    pass


class DynamodbRegionsSingletonUpdateError(BaseDomainsException):
    def __init__(self, region):
        self.region = region


class DynamodbAuthError(BaseDomainsException):
    pass


class GenericBotoError(BaseDomainsException):
    pass
