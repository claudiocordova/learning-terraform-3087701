class BaseDownloadUrlFactoryException(Exception):
    pass


class S3ObjectDoesNotExist(BaseDownloadUrlFactoryException):
    def __init__(self, s3_key: str, bucket: str):
        self.s3_key = s3_key
        self.bucket = bucket


class S3ObjectKeyMissing(BaseDownloadUrlFactoryException):
    def __init__(self, s3_prefix: str, bucket: str):
        self.s3_prefix = s3_prefix
        self.bucket = bucket


class GenericBotoError(BaseDownloadUrlFactoryException):
    pass
