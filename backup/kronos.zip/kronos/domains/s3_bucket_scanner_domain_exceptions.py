class BaseS3BucketScannerException(Exception):
    pass


class InvalidBatchSize(BaseS3BucketScannerException):
    def __init__(self, size):
        self.size = size


class ValidationError(BaseS3BucketScannerException):
    pass


class AuthError(BaseS3BucketScannerException):
    pass


class GenericBotoError(BaseS3BucketScannerException):
    pass


class SqsSendMessageError(BaseS3BucketScannerException):
    def __init__(self, failed_messages):
        self.failed_messages = failed_messages
