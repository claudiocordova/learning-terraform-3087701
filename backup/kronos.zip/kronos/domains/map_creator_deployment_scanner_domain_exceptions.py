class BaseDatasetItemException(Exception):
    pass


class DeploymentClientAuthError(BaseDatasetItemException):
    pass


class DatasetEnvironmentUpdateError(BaseDatasetItemException):
    def __init__(self, region, session):
        self.region = region
        self.session = session


class DeploymentIdentifierNotFound(BaseDatasetItemException):
    def __init__(self, deployment_identifier):
        self.deployment_identifier = deployment_identifier


class MalformedMapDataClientResponse(BaseDatasetItemException):
    pass
