import json
from typing import Optional, Set

from botocore.exceptions import ClientError

from ..conf import settings
from ..data_models import base_model_exceptions, region_singleton_model_exceptions
from ..data_models.dataset_model import ArtifactsStatusEnum, DatasetFacet
from ..utils.boto3_utils import get_s3_resource, has_s3_object
from ..utils.dynamodb_utils import ReturnValuesEnum, dynamize
from ..utils.log_utils import logger
from . import base_domain_exceptions
from . import s3_dataset_scanner_domain_exceptions as exceptions
from .s3_artifact_scanner_domain import (
    AbstractArtifactScanner,
    ArtifactRequirementEnum,
    BevArtifactScanner,
    ColorTilesArtifactScanner,
    GpkgArtifactScanner,
    IcpMapV1ArtifactScanner,
    IcpMapV2ArtifactScanner,
    NonColorTilesArtifactScanner,
    PcdArtifactScanner,
    RoadMetricsArtifactScanner,
)

IGNORED_DRIVE_SESSION_VALUES = (
    "MERGE",
    "LEGACY_BML1",
    "UPDATE",
    "ONE_SHOT_MERGE",
    "UNKNOWN",
)


class S3DatasetScanner:
    def __init__(self, region: str, session: str):
        self.region = region
        self.session = session
        self.s3_resource = get_s3_resource()

    def create_or_update_dataset(
        self,
        do_scan_all_artifacts: Optional[bool] = None,
        do_scan_gpkg: Optional[bool] = None,
        do_scan_icp_map_v2: Optional[bool] = None,
        do_scan_non_color_tiles: Optional[bool] = None,
        do_scan_color_tiles: Optional[bool] = None,
        do_scan_pcd: Optional[bool] = None,
        do_scan_road_metrics: Optional[bool] = None,
        do_scan_bev: Optional[bool] = None,
        do_scan_icp_map_v1: Optional[bool] = None,
    ) -> None:
        """
        Create or update a dataset with data retrieved from metadata.json and by
         optionally scanning for artifacts in S3.
        """
        # Validate the remote S3 dataset dir to avoid writing invalid datasets to DB.
        try:
            if not has_s3_object(
                settings.S3_BUCKET_NAME_BASEMAPDB,
                f"{self.region}/{self.session}/graph.sqlite3",
            ):
                raise exceptions.InvalidDatasetRemoteDir(
                    region=self.region, session=self.session
                )
        except ClientError as exc:
            raise exceptions.BaseS3DatasetScannerException from exc

        attrs_to_update = dict()

        # Parse metadata.json.
        metadata_json_content = self.get_metadata_json_content()
        if len(metadata_json_content) != 0:
            # Limit to 50 files as some Spark datasets have a large number of files that
            #  exceeds DynamoDB's max allowed item size resulting in:
            #  [ERROR] ClientError: An error occurred (ValidationException) when calling the UpdateItem operation: Item size to update has exceeded the maximum allowed size
            attrs_to_update["graph_data_files"] = list(
                metadata_json_content["map_files"].keys()
            )[: settings.MAX_MAP_FILES]
            if len(metadata_json_content["map_files"]) > settings.MAX_MAP_FILES:
                attrs_to_update["graph_data_files"].append("...")
            attrs_to_update["session_hierarchy"] = (
                metadata_json_content["session_hierarchy"]
                if isinstance(metadata_json_content["session_hierarchy"], list)
                else []
            )
            try:
                drivelog = self._parse_drivelog(metadata_json_content["drive_session"])
            except KeyError:
                # Faulty datasets were uploaded into `motional-basemapdb-prod`. These `metadata.json` files do
                #  not contain `drive_session` which deviates from the previously agreed upon `metadata.json`
                #  interface.
                # Once these faulty datasets are removed, we can stop supporting such a use case.
                # Example: test-maplets/2022-07-26_05-54-12-GMT/metadata.json
                logger.info(
                    f"`drive_session` key missing: {self.region}/{self.session}/metadata.json"
                )
                raise exceptions.MetadataJsonContentError(
                    self.region,
                    self.session,
                    f"{self.region}/{self.session}/metadata.json",
                )
            if drivelog:
                attrs_to_update["drivelog"] = drivelog
            attrs_to_update["operation_type"] = metadata_json_content["operation_type"]
            # DynamoDB doesn't support float attribute type.
            #  See:
            #   - https://github.com/boto/boto3/issues/665
            #   - https://github.com/boto/boto3/issues/369
            # We could also use Decimal but odometer_distance can be `UNKNOWN` so string here is more appropriate.
            attrs_to_update["odometer_distance"] = str(
                metadata_json_content["odometer_distance"]
            )

        # Scan artifacts.
        artifact_scanners: Set[AbstractArtifactScanner] = set()
        if do_scan_all_artifacts:
            artifact_scanners = AbstractArtifactScanner.make_scanners_from_requirement(
                region=self.region,
                session=self.session,
                artifact_requirement_enum=ArtifactRequirementEnum.ALL,
            )
        else:
            if do_scan_gpkg:
                artifact_scanners.add(GpkgArtifactScanner(self.region, self.session))
            if do_scan_icp_map_v2:
                artifact_scanners.add(
                    IcpMapV2ArtifactScanner(self.region, self.session)
                )
            if do_scan_non_color_tiles:
                artifact_scanners.add(
                    NonColorTilesArtifactScanner(self.region, self.session)
                )
            if do_scan_color_tiles:
                artifact_scanners.add(
                    ColorTilesArtifactScanner(self.region, self.session)
                )
            if do_scan_pcd:
                artifact_scanners.add(PcdArtifactScanner(self.region, self.session))
            if do_scan_road_metrics:
                artifact_scanners.add(
                    RoadMetricsArtifactScanner(self.region, self.session)
                )
            if do_scan_bev:
                artifact_scanners.add(BevArtifactScanner(self.region, self.session))
            if do_scan_icp_map_v1:
                artifact_scanners.add(
                    IcpMapV1ArtifactScanner(self.region, self.session)
                )

        if artifact_scanners:
            for scanner in artifact_scanners:
                attrs_to_update[f"has_{scanner.artifact_name}"] = scanner.has_artifact

            artifacts_status = AbstractArtifactScanner.determine_artifacts_status(
                region=self.region,
                session=self.session,
                artifact_scanners=artifact_scanners,
            )
            if artifacts_status is not None:
                attrs_to_update["artifacts_status"] = artifacts_status

        # Update the DB DatasetItem and get response with all attributes.
        response = self._run_create_or_update_dataset(
            return_values=ReturnValuesEnum.ALL_NEW, **attrs_to_update
        )

        # Did not scan any artifacts, don't need to update `artifacts_status`.
        if not artifact_scanners:
            return

        # Already scanned all required artifacts and updated `artifacts_status`.
        if do_scan_all_artifacts or (
            do_scan_gpkg
            and do_scan_icp_map_v2
            and do_scan_non_color_tiles
            and do_scan_color_tiles
            and do_scan_pcd
            and do_scan_road_metrics
        ):
            return

        # If at least one required artifact is missing, don't update `artifacts_status`.
        for name in AbstractArtifactScanner.get_required_artifact_names():
            if not response["Attributes"].get(dynamize(f"has_{name}"), False):
                return

        # All artifacts exist in DB DatasetItem, update DB DatasetItem `artifacts_status`.
        self._run_create_or_update_dataset(
            return_values=ReturnValuesEnum.NONE,
            artifacts_status=ArtifactsStatusEnum.ALL_REQUIRED.value,
        )

    def get_metadata_json_content(self) -> dict:
        # TODO BAS-2510 use s3_client lib extracted from map-cli instead.
        #  Also do not hardcode s3 keys in this file but create a lib that knows about
        #  s3 keys. See remote data models in map-cli.
        s3_key = f"{self.region}/{self.session}/metadata.json"
        source_obj = self.s3_resource.Object(settings.S3_BUCKET_NAME_BASEMAPDB, s3_key)

        # Using try except here instead of has_s3_object saves us one object.load.
        try:
            body = source_obj.get()["Body"].read()
        except ClientError:
            logger.error(f"The S3 key for metadata.json does not exist: {s3_key}")
            raise exceptions.MetadataJsonNotFound(self.region, self.session, s3_key)

        try:
            data = json.loads(body)
        except json.JSONDecodeError as exc:
            logger.error(f"metadata.json is not in JSON format: {s3_key}")
            raise exceptions.MetadataJsonContentError(self.region, self.session, s3_key)
        logger.debug("metadata.json parsed", extra=dict(metadata_json=data))
        return data

    @staticmethod
    def _parse_drivelog(drivelog) -> Optional[str]:
        if drivelog in IGNORED_DRIVE_SESSION_VALUES:
            return None
        return drivelog

    def _run_create_or_update_dataset(self, return_values, **attrs_to_update) -> dict:
        dataset_facet = DatasetFacet(self.region, self.session)
        try:
            response = dataset_facet.create_or_update(
                return_values=return_values, **attrs_to_update
            )
        except region_singleton_model_exceptions.RegionSingletonRegionsAttrNotAStringSet as exc:
            raise base_domain_exceptions.DynamodbRegionsSingletonUpdateError(
                self.region
            ) from exc
        except base_model_exceptions.AuthError as exc:
            raise base_domain_exceptions.DynamodbAuthError from exc
        return response
