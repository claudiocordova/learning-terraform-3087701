import requests
from map_data_client import base_client_exceptions, location_client_exceptions
from map_data_client.location_client import LocationClient

from ..utils.log_utils import logger
from . import location_url_factory_domain_exceptions as exceptions


class LocationUrlFactory:
    def __init__(self, region: str, session: str):
        self.region = region
        self.session = session

    def make_location_url(self) -> str:
        logger.info(
            f"Fetching Map Creator location url for: {self.region} {self.session}"
        )
        try:
            location_client = LocationClient()
            response = location_client.get_location_info(
                region=self.region, session=self.session
            )
            response.raise_for_status()
            location_id = response.basemap_location_info.location_id
            url = f"https://editor.maps.motional.com/locations/view/{self.region}/{location_id}"
        except location_client_exceptions.LocationNotFound as exc:
            logger.exception("Received malformed response from map creator")
            raise exceptions.LocationUrlNotFound(self.region, self.session) from exc
        except base_client_exceptions.MalformedResponse as exc:
            logger.exception("Received malformed response from map creator")
            raise exceptions.LocationRequestError from exc
        except (
            requests.ConnectionError,
            requests.HTTPError,
        ) as exc:  # Connection error occurs when the request is made outside the VPN.
            logger.exception("Error retrieving location from Map Creator API")
            raise exceptions.LocationRequestError from exc
        logger.info(f"Location url for {self.region} {self.session}: {url}")
        return url
