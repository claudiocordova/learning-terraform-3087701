class BaseS3ArtifactScannerException(Exception):
    pass
