from aws_lambda_powertools.utilities.data_classes import SNSEvent


class BaseServiceRunDomainException(Exception):
    pass


class IncomingEventUnknown(BaseServiceRunDomainException):
    def __init__(self, sns_event: SNSEvent):
        self.sns_event = sns_event


class DynamodbServiceRunCreateError(BaseServiceRunDomainException):
    pass


class DynamodbDatasetDoesNotExist(BaseServiceRunDomainException):
    pass


class SnsAuthError(BaseServiceRunDomainException):
    pass
