import json
from functools import lru_cache
from typing import Any, Dict, Iterator, Optional, Tuple

from aws_lambda_powertools.utilities.data_classes import SQSEvent
from aws_lambda_powertools.utilities.data_classes.sqs_event import SQSRecord
from botocore import exceptions as botocore_exceptions

from ..conf import settings
from ..utils.boto3_utils import get_s3_client, get_sqs_queue_resource
from ..utils.log_utils import logger
from . import base_domain_exceptions
from . import s3_bucket_scanner_domain_exceptions as exceptions
from . import s3_dataset_scanner_domain_exceptions
from .s3_dataset_scanner_domain import S3DatasetScanner

S3_DATASET_SCANNER_TASK_ID = "S3_DATASET_SCANNER"


class S3BucketScanner:
    def __init__(self):
        # TODO BAS-2510 use standalone s3_client.
        self.s3_client = get_s3_client()

    def yield_potential_datasets(self) -> Iterator[Tuple[str, str]]:
        for region in self.get_region_prefixes():
            for session in self.get_session_prefixes(region):
                yield region, session

    def yield_confirmed_datasets(self) -> Iterator[Tuple[str, str]]:
        # TODO implement this by checking for the presence of the graph.sqlite3 file in
        #  a dataset in order for it to be considered "confirmed".
        raise NotImplementedError

    def get_region_prefixes(self) -> Iterator[str]:
        # TODO BAS-2510 use standalone s3_client.
        # Info on use of pagination and delimiter: https://stackoverflow.com/a/51372405/17736857
        # Use `Delimiter="/"` to list only the subdirs, not recursively, very fast: https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-prefixes.html
        regions_result = self.s3_client.get_paginator("list_objects_v2").paginate(
            Bucket=settings.S3_BUCKET_NAME_BASEMAPDB, Delimiter="/"
        )

        try:
            for region_prefix in regions_result.search("CommonPrefixes"):
                # If the return is None, it means there are no regions. Unlikely to happen but not impossible.
                if region_prefix is None:
                    break
                region = region_prefix.get("Prefix")
                if len(region) > 1:
                    region = region[:-1]
                yield region
        except botocore_exceptions.NoCredentialsError as exc:
            raise exceptions.AuthError from exc
        except (
            botocore_exceptions.BotoCoreError,
            botocore_exceptions.ClientError,
        ) as exc:
            raise exceptions.GenericBotoError from exc

    def get_session_prefixes(self, region) -> Iterator[str]:
        # TODO BAS-2510 use standalone s3_client.
        # Info on use of pagination and delimiter: https://stackoverflow.com/a/51372405/17736857
        sessions_result = self.s3_client.get_paginator("list_objects_v2").paginate(
            Bucket=settings.S3_BUCKET_NAME_BASEMAPDB,
            Prefix=f"{region}/",
            Delimiter="/",
        )

        try:
            for session_prefix in sessions_result.search("CommonPrefixes"):
                # If the return is None, it means there are no sessions.
                if session_prefix is None:
                    break
                # This can never result in IndexError because we use Delimiter="/".
                session = session_prefix.get("Prefix").split("/")[1]
                yield session
        except botocore_exceptions.NoCredentialsError as exc:
            raise exceptions.AuthError from exc
        except (
            botocore_exceptions.BotoCoreError,
            botocore_exceptions.ClientError,
        ) as exc:
            raise exceptions.GenericBotoError from exc


class S3DatasetScannerProducer:
    def __init__(
        self,
        # Max is 10, see: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/sqs.html#SQS.Queue.send_messages
        batch_size: Optional[int] = 10,
    ):
        if batch_size < 1 or batch_size > 10:
            logger.error(f"Invalid batch_size: {batch_size}")
            raise exceptions.InvalidBatchSize(size=batch_size)
        self.batch_size = batch_size
        self._task_queue = []
        # TODO BAS-2510 use standalone sqs_client instead.
        self.sqs_queue = get_sqs_queue_resource()

    def enqueue_task(self, region, session, do_early_submit=True) -> None:
        self._task_queue.append((region, session))
        if not do_early_submit:
            return
        if len(self._task_queue) < self.batch_size:
            return
        self.submit_all_enqueued_tasks()

    def submit_all_enqueued_tasks(self) -> None:
        for i in range(0, len(self._task_queue), self.batch_size):
            task_batch = self._task_queue[i : i + self.batch_size]
            message_batch = []
            for index, (region, session) in enumerate(task_batch):
                message_batch.append(
                    {
                        "Id": str(index),
                        "MessageBody": S3DatasetScannerTask(region, session).to_json(),
                        "MessageAttributes": {
                            "content_type": {
                                "DataType": "String",
                                "StringValue": "application/json",
                            }
                        },
                        "DelaySeconds": 0,
                    }
                )

            try:
                response = self.sqs_queue.send_messages(Entries=message_batch)
            except botocore_exceptions.NoCredentialsError as exc:
                raise exceptions.AuthError from exc
            except (
                botocore_exceptions.BotoCoreError,
                botocore_exceptions.ClientError,
            ) as exc:
                raise exceptions.GenericBotoError from exc

            failed_messages = response.get("Failed")
            if failed_messages:
                raise exceptions.SqsSendMessageError(failed_messages=failed_messages)

        self._task_queue.clear()


class S3DatasetScannerConsumer:
    def __init__(self, raw_incoming_event: Dict[str, Any]):
        self.sqs_event = SQSEvent(raw_incoming_event)

    def execute_task(self, do_ignore_invalid_dataset_remote_dirs=True) -> None:
        if self.sqs_event._data.get("Records") is None:
            raise exceptions.ValidationError('Malformed SQS message: no ["Records"]')

        for record in self.sqs_event.records:
            record: SQSRecord
            try:
                task = S3DatasetScannerTask.make_from_raw_event_json(record)
            except exceptions.ValidationError as exc:
                logger.warning(
                    "Invalid S3_DATASET_SCANNER Task",
                    extra=dict(sqs_record_body=record.body),
                )
                continue

            scanner = S3DatasetScanner(task.region, task.session)
            try:
                scanner.create_or_update_dataset(do_scan_all_artifacts=True)
            except (
                s3_dataset_scanner_domain_exceptions.InvalidDatasetRemoteDir,
                s3_dataset_scanner_domain_exceptions.MetadataJsonNotFound,
                s3_dataset_scanner_domain_exceptions.MetadataJsonContentError,
            ) as exc:
                if do_ignore_invalid_dataset_remote_dirs:
                    logger.info(
                        "Ignoring invalid dataset remote dir in S3",
                        extra=dict(region=task.region, session=task.session),
                    )
                else:
                    raise
            except base_domain_exceptions.BaseDomainsException as exc:
                logger.exception(
                    f"Failed to execute S3_DATASET_SCANNER task",
                    extra=dict(region=task.region, session=task.session),
                )
                raise exc


class S3DatasetScannerTask:
    def __init__(self, region, session):
        self.region = region
        self.session = session

    def to_dict(self) -> dict:
        # Used by S3DatasetScannerProducer to build the Message Attributes when enqueuing tasks.
        return {
            "task_id": S3_DATASET_SCANNER_TASK_ID,
            "region": self.region,
            "session": self.session,
        }

    @lru_cache
    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @staticmethod
    def make_from_raw_event_json(record: SQSRecord) -> "S3DatasetScannerTask":
        try:
            data = json.loads(record.body)
        except json.JSONDecodeError as exc:
            raise exceptions.ValidationError(f"Invalid json record body: {record.body}")

        if (task_id := data.get("task_id")) != S3_DATASET_SCANNER_TASK_ID:
            raise exceptions.ValidationError(f"Invalid task_id: {task_id}")
        if (region := data.get("region")) is None:
            raise exceptions.ValidationError("Invalid region: None")
        if (session := data.get("session")) is None:
            raise exceptions.ValidationError("Invalid session: None")

        return S3DatasetScannerTask(region=region, session=session)
