from typing import List

from botocore.exceptions import BotoCoreError, ClientError

from ..conf import settings
from ..utils.boto3_utils import get_s3_client, has_s3_object
from ..utils.log_utils import logger
from . import download_url_factory_domain_exceptions as exceptions

SECOND = 1
MINUTE = 60 * SECOND
HOUR = 60 * MINUTE


class GpkgDownloadUrlFactory:
    def __init__(self, region: str, session: str):
        self.region = region
        self.session = session

    def make_download_url(self) -> str:
        # TODO: Refactor to use s3_client from new library instead of boto3 directly: https://jira.ci.motional.com/atljira/browse/BAS-2510

        s3_key: str = f"{self.region}/{self.session}/resources/{self.region}-{self.session}-basemap.gpkg"

        # `generate_presigned_url` is a local operation that does not verify that the remote file exists.
        # See: https://github.com/boto/botocore/issues/1666#issuecomment-482247549
        # So we explicitly verify that the remote file exists.
        if not has_s3_object(settings.S3_BUCKET_NAME_BASEMAPDB, s3_key):
            raise exceptions.S3ObjectDoesNotExist(
                s3_key, settings.S3_BUCKET_NAME_BASEMAPDB
            )

        logger.info(f"Generating pre-signed url for: {s3_key}")
        try:
            url = get_s3_client().generate_presigned_url(
                ClientMethod="get_object",
                Params={"Bucket": settings.S3_BUCKET_NAME_BASEMAPDB, "Key": s3_key},
                ExpiresIn=12 * HOUR,  # 12 hours, default is 1 hour.
            )
        except (BotoCoreError, ClientError) as exc:
            raise exceptions.GenericBotoError from exc
        logger.info(f"Pre-signed url with TTL 12 hour for {s3_key}: {url}")
        return url


class PoseGraphValidatorResidualDownloadUrlFactory:
    def __init__(self, region: str, session: str):
        self.region = region
        self.session = session
        self.s3_client = get_s3_client()

    def list_files(self) -> List[str]:
        """
        Return of list of files in <region>/<session>/pose-graph-validator.
        """
        s3_prefix: str = f"{self.region}/{self.session}/pose-graph-validator"

        result = self.s3_client.get_paginator("list_objects_v2").paginate(
            Bucket=settings.S3_BUCKET_NAME_BASEMAPDB,
            Prefix=f"{s3_prefix}/",
            Delimiter="/",
        )
        files = []
        # Get a list of all files in the folder <region>/<session>/pose-graph-validator.
        for page in result:
            for object in page.get("Contents", []):
                try:
                    files.append(object["Key"])
                except KeyError:
                    raise exceptions.S3ObjectKeyMissing(
                        s3_prefix, settings.S3_BUCKET_NAME_BASEMAPDB
                    )
        return files

    def does_artifact_exist(self, filename: str) -> bool:
        s3_key: str = f"{self.region}/{self.session}/pose-graph-validator/{filename}"
        try:
            if not has_s3_object(settings.S3_BUCKET_NAME_BASEMAPDB, s3_key):
                return False
            return True
        except ClientError:
            raise

    def make_download_url(self, filename: str) -> str:
        """
        Return a pre-signed url to download a file with the s3 prefix <region>/<session>/pose-graph-validator
        """
        s3_key: str = f"{self.region}/{self.session}/pose-graph-validator/{filename}"

        # `generate_presigned_url` is a local operation that does not verify that the remote file exists.
        # See: https://github.com/boto/botocore/issues/1666#issuecomment-482247549
        # So we explicitly verify that the remote file exists.
        if not self.does_artifact_exist(filename):
            raise exceptions.S3ObjectDoesNotExist(
                s3_key, settings.S3_BUCKET_NAME_BASEMAPDB
            )

        logger.info(f"Generating pre-signed url for: {s3_key}")
        try:
            url = get_s3_client().generate_presigned_url(
                ClientMethod="get_object",
                Params={"Bucket": settings.S3_BUCKET_NAME_BASEMAPDB, "Key": s3_key},
                ExpiresIn=12 * HOUR,  # 12 hours, default is 1 hour.
            )
        except (BotoCoreError, ClientError) as exc:
            raise exceptions.GenericBotoError from exc
        logger.info(f"Pre-signed url with TTL 12 hour for {s3_key}: {url}")
        return url
