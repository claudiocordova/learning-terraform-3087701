from map_data_client import base_client_exceptions
from map_data_client import base_client_exceptions as base_map_data_client_exceptions
from map_data_client import deployment_client_exceptions
from map_data_client.deployment_client import (
    DeploymentClient,
    GetActiveplanMapsResponse,
)
from map_data_client.utils import (
    boto3_utils_exceptions as deployment_client_boto3_utils_exceptions,
)

from ..data_models import base_model_exceptions
from ..data_models.dataset_model import DatasetFacet, EnvironmentEnum
from utils import dataset_utils
from utils.log_utils import logger
from . import base_domain_exceptions
from . import map_creator_deployment_scanner_domain_exceptions as exceptions


class MapCreatorDeploymentScanner:
    def __init__(self):
        self._deployment_client = DeploymentClient()
        self.envs = (
            EnvironmentEnum.PRE_PRODUCTION.value,
            EnvironmentEnum.GEN2_PRODUCTION.value,
        )

    def update_datasets(self) -> None:
        # Any of the deployment_identifiers may result in failure, but we still want
        #  to continue to execute the remaining identifiers. So we collect exceptions
        #  here and raise at the end.
        collected_exceptions = list()

        for env in self.envs:
            logger.info(f"Retrieving activeplan maps: {env}")
            try:
                response: GetActiveplanMapsResponse = (
                    self._deployment_client.get_activeplan_maps(env)
                )
            except (
                deployment_client_boto3_utils_exceptions.Boto3AuthError,
                deployment_client_boto3_utils_exceptions.MalformedSecret,
                deployment_client_boto3_utils_exceptions.SecretNotFound,
            ):
                collected_exceptions.append(exceptions.DeploymentClientAuthError)
                continue

            try:
                response.raise_for_status()
            except (
                base_map_data_client_exceptions.AuthError,
                deployment_client_exceptions.NoAccessTokenInAuth0Response,
            ) as exc:
                # Store the exception and continue, re-raise it later.
                collected_exceptions.append(exceptions.DeploymentClientAuthError)
                continue
            except deployment_client_exceptions.DeploymentIdentifierNotFound as exc:
                # Store the exception and continue, re-raise it later.
                collected_exceptions.append(
                    exceptions.DeploymentIdentifierNotFound(deployment_identifier=env)
                )
                continue

            try:
                for dataset_info in response.basemap_datasets_info:
                    rs = dict(region=dataset_info.region, session=dataset_info.session)
                    logger.info(
                        f"Updating environment for dataset",
                        extra=dict(environment=env, **rs),
                    )
                    dataset = DatasetFacet(dataset_info.region, dataset_info.session)
                    try:
                        dataset.update(environment=env)
                    except base_model_exceptions.ItemNotFound as exc:
                        cls = __class__.__name__
                        # If it is a known legacy dataset, then it was not found in the DB
                        #  because we just do not store legacy datasets.
                        if dataset_utils.is_known_legacy_dataset(
                            dataset_info.region, dataset_info.session
                        ):
                            logger.info(f"{cls}: skipping legacy dataset", rs)
                            continue
                        # Otherwise log the missing dataset but continue to update the
                        #  remaining datasets.
                        logger.exception(f"{cls}: dataset does not exist in DB", rs)
                    except base_model_exceptions.AuthError as exc:
                        raise base_domain_exceptions.DynamodbAuthError from exc
            except base_client_exceptions.MalformedResponse as exc:
                collected_exceptions.append(
                    exceptions.MalformedMapDataClientResponse(exc)
                )
                continue

        if collected_exceptions:
            logger.error(
                "Collected exceptions", extra=dict(exceptions=collected_exceptions)
            )
            # Raise the first exception only.
            raise collected_exceptions[0]
