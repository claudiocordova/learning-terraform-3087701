class BaseS3DatasetScannerException(Exception):
    pass


class InvalidDatasetRemoteDir(BaseS3DatasetScannerException):
    def __init__(self, region, session):
        self.region = region
        self.session = session


class MetadataJsonNotFound(BaseS3DatasetScannerException):
    def __init__(self, region, session, s3_key):
        self.region = region
        self.session = session
        self.s3_key = s3_key


class MetadataJsonContentError(BaseS3DatasetScannerException):
    def __init__(self, region, session, s3_key):
        self.region = region
        self.session = session
        self.s3_key = s3_key
