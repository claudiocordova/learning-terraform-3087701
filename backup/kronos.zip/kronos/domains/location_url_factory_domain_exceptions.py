class BaseLocationUrlException(Exception):
    pass


class LocationUrlNotFound(BaseLocationUrlException):
    def __init__(self, region: str, session: str):
        self.region = region
        self.session = session


class LocationRequestError(BaseLocationUrlException):
    pass
