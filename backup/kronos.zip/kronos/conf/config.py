from pathlib import Path

import map_data_client.conf.config as map_data_client_config
from dynaconf import Dynaconf

import events.conf.config as events_config

conf_dir = Path(__file__).parent.resolve()

settings = Dynaconf(
    envvar_prefix="MUNDI",
    settings_files=[
        conf_dir / "settings_default.toml",
        conf_dir / "settings_development.toml",
        conf_dir / "settings_test.toml",
        conf_dir / ".secrets.toml",
    ],
    environments=True,
)

# Forward settings to libraries.
events_config.update_settings(settings)
map_data_client_config.update_settings(settings)
