class BaseSlackNotificationDrivelogsSingletonItemException(Exception):
    pass


class NotASlackNotificationDrivelogsSingletonItem(
    BaseSlackNotificationDrivelogsSingletonItemException
):
    pass


class SlackNotificationDrivelogsSingletonSlackNotificationDrivelogsAttrNotAStringSet(
    BaseSlackNotificationDrivelogsSingletonItemException
):
    pass
