from typing import Set

from boto3.dynamodb.conditions import Attr, Key, Not
from mypy_boto3_dynamodb.type_defs import (
    DeleteItemOutputTableTypeDef,
    GetItemOutputTableTypeDef,
    PutItemOutputTableTypeDef,
    UpdateItemOutputTableTypeDef,
)

from ..utils.boto3_utils import get_table_resource
from ..utils.log_utils import logger
from . import base_model_exceptions
from . import slack_notification_drivelogs_singleton_model_exceptions as exceptions
from .base_model import handle_auth_exceptions


class SlackNotificationDrivelogsSingletonItem:
    def __init__(self, drivelogs: Set[str] = None):
        self.item_type = SlackNotificationDrivelogsSingletonFacet.ITEM_TYPE
        self.drivelogs: set[str] = drivelogs

    @property
    def pk(self):
        return SlackNotificationDrivelogsSingletonFacet.make_pk()

    @property
    def sk(self):
        return SlackNotificationDrivelogsSingletonFacet.make_sk()

    @classmethod
    def from_db(cls, data) -> "SlackNotificationDrivelogsSingletonItem":
        if data.get("ItemType") != SlackNotificationDrivelogsSingletonFacet.ITEM_TYPE:
            raise exceptions.NotASlackNotificationDrivelogsSingletonItem

        model = cls(
            drivelogs=data.get(
                SlackNotificationDrivelogsSingletonFacet.ATTRIBUTES_MAP["drivelogs"]
            ),
        )
        model.item_type = data.get(
            SlackNotificationDrivelogsSingletonFacet.ATTRIBUTES_MAP["item_type"]
        )
        return model


class SlackNotificationDrivelogsSingletonFacet:
    ITEM_TYPE = "SlackNotificationDrivelogsSingleton"

    ATTRIBUTES_MAP = dict(
        # pk="PK",
        # sk="SK",
        item_type="ItemType",
        drivelogs="Drivelogs",
    )

    @staticmethod
    def make_pk() -> str:
        return "SLACKNOTIFICATIONDRIVELOGS"

    @staticmethod
    def make_sk() -> str:
        return SlackNotificationDrivelogsSingletonFacet.make_pk()

    @handle_auth_exceptions
    def create(
        self, drivelogs: Set[str] = None, do_overwrite=False
    ) -> SlackNotificationDrivelogsSingletonItem:
        item = SlackNotificationDrivelogsSingletonItem(drivelogs)
        try:
            # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.put_item
            response: PutItemOutputTableTypeDef = get_table_resource().put_item(
                Item={
                    "PK": self.make_pk(),
                    "SK": self.make_sk(),
                    self.ATTRIBUTES_MAP["item_type"]: self.ITEM_TYPE,
                    self.ATTRIBUTES_MAP["drivelogs"]: drivelogs,
                },
                # Do not overwrite.
                ConditionExpression=Attr("PK").not_exists() if not do_overwrite else "",
                ReturnValues="NONE",
            )
        except get_table_resource().meta.client.exceptions.ConditionalCheckFailedException as exc:
            raise base_model_exceptions.PrimaryKeyConstraintError(item) from exc

        logger.debug("Response", extra=dict(response=response))
        return item

    @handle_auth_exceptions
    def delete(self) -> None:
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.delete_item
        response: DeleteItemOutputTableTypeDef = get_table_resource().delete_item(
            Key={"PK": self.make_pk(), "SK": self.make_sk()}
        )
        logger.debug("Response", extra=dict(response=response))

    @handle_auth_exceptions
    def read(self) -> SlackNotificationDrivelogsSingletonItem:
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.get_item
        response: GetItemOutputTableTypeDef = get_table_resource().get_item(
            Key={"PK": self.make_pk(), "SK": self.make_sk()}
        )
        logger.debug("Response", extra=dict(response=response))
        if not response.get("Item"):
            raise base_model_exceptions.ItemNotFound

        item = SlackNotificationDrivelogsSingletonItem.from_db(response["Item"])
        return item

    @handle_auth_exceptions
    def does_exist(self) -> bool:
        try:
            self.read()
        except base_model_exceptions.ItemNotFound:
            return False
        return True

    @handle_auth_exceptions
    def contains_drivelog(self, drivelog: str) -> bool:
        response = get_table_resource().query(
            Select="COUNT",
            KeyConditionExpression=(
                Key("PK").eq(self.make_pk()) & Key("SK").eq(self.make_sk())
            ),
            FilterExpression=(
                Attr(self.ATTRIBUTES_MAP["drivelogs"]).contains(drivelog)
            ),
        )
        return response["Count"] == 1

    @handle_auth_exceptions
    def add_drivelog(self, drivelog: str) -> None:
        try:
            # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.update_item
            response: UpdateItemOutputTableTypeDef = get_table_resource().update_item(
                **self.make_update_expression(drivelog)
            )
            logger.debug("Response", extra=dict(response=response))
        except get_table_resource().meta.client.exceptions.ConditionalCheckFailedException:
            # The drivelog already exists in SlackNotificationDrivelogsSingleton.drivelogs, no action required.
            logger.info(
                f"Drivelog already exists in SlackNotificationDrivelogsSingleton: {drivelog}"
            )
        except get_table_resource().meta.client.exceptions.ClientError as exc:
            if exc.response["Error"]["Code"] == "ValidationException":
                raise exceptions.SlackNotificationDrivelogsSingletonSlackNotificationDrivelogsAttrNotAStringSet from exc
            raise

    @handle_auth_exceptions
    def remove_drivelog(self, drivelog: str) -> None:
        try:
            # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.update_item
            response: UpdateItemOutputTableTypeDef = get_table_resource().update_item(
                **self.make_update_expression(drivelog, do_remove_drivelog=True)
            )
            print(response)
            logger.debug("Response", extra=dict(response=response))
        except get_table_resource().meta.client.exceptions.ConditionalCheckFailedException as exc:
            # The drivelog does not exist in SlackNotificationDrivelogsSingleton.drivelogs, no action required.
            logger.info(
                f"Drivelog does not exist in SlackNotificationDrivelogsSingleton: {drivelog}"
            )
        except get_table_resource().meta.client.exceptions.ClientError as exc:
            if exc.response["Error"]["Code"] == "ValidationException":
                raise exceptions.SlackNotificationDrivelogsSingletonSlackNotificationDrivelogsAttrNotAStringSet from exc
            raise

    @classmethod
    def make_update_expression(
        cls, drivelog: str, do_remove_drivelog: bool = False
    ) -> dict:
        """
        Make an expression to be used with update_item() to add a drivelog to the set
         SlackNotificationDrivelogsSingleton.Drivelogs.
        """
        condition_expression = Not(
            Attr(cls.ATTRIBUTES_MAP["drivelogs"]).contains(drivelog)
        )
        update_expression = "ADD #drivelogs :drivelog SET #item_type = :item_type"
        if do_remove_drivelog:
            condition_expression = Attr(cls.ATTRIBUTES_MAP["drivelogs"]).contains(
                drivelog
            )
            update_expression = (
                "DELETE #drivelogs :drivelog SET #item_type = :item_type"
            )
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.update_item
        expression = {
            "Key": {"PK": cls.make_pk(), "SK": cls.make_sk()},
            # Note: if we add Attr("PK").not_exists() into ConditionExpression then
            #  when the condition expression fails, we would not be able to
            #  differentiate between the two expressions.
            "ConditionExpression": condition_expression,
            "UpdateExpression": update_expression,
            "ExpressionAttributeNames": {
                "#item_type": cls.ATTRIBUTES_MAP["item_type"],
                "#drivelogs": cls.ATTRIBUTES_MAP["drivelogs"],
            },
            "ExpressionAttributeValues": {
                ":drivelog": {drivelog},
                ":item_type": cls.ITEM_TYPE,
            },
            "ReturnValues": "NONE",
        }
        return expression
