from typing import Set

from boto3.dynamodb.conditions import Attr, Not
from mypy_boto3_dynamodb.type_defs import (
    DeleteItemOutputTableTypeDef,
    GetItemOutputTableTypeDef,
    PutItemOutputTableTypeDef,
    UpdateItemOutputTableTypeDef,
)

from ..utils.boto3_utils import get_table_resource
from ..utils.log_utils import logger
from . import base_model_exceptions
from . import region_singleton_model_exceptions as exceptions
from .base_model import handle_auth_exceptions


class RegionSingletonItem:
    def __init__(self, regions: Set[str] = None):
        # TODO add validation (marshmallow?).
        self.item_type = RegionSingletonFacet.ITEM_TYPE
        self.regions: set[str] = regions

    @property
    def pk(self):
        return RegionSingletonFacet.make_pk()

    @property
    def sk(self):
        return RegionSingletonFacet.make_sk()

    @classmethod
    def from_db(cls, data) -> "RegionSingletonItem":
        if data.get("ItemType") != RegionSingletonFacet.ITEM_TYPE:
            raise exceptions.NotARegionSingletonItem

        model = cls(
            regions=data.get(RegionSingletonFacet.ATTRIBUTES_MAP["regions"]),
        )
        model.item_type = data.get(RegionSingletonFacet.ATTRIBUTES_MAP["item_type"])
        return model


class RegionSingletonFacet:
    ITEM_TYPE = "RegionSingleton"

    ATTRIBUTES_MAP = dict(
        # pk="PK",
        # sk="SK",
        item_type="ItemType",
        regions="Regions",
    )

    @staticmethod
    def make_pk() -> str:
        return "REGIONS"

    @staticmethod
    def make_sk() -> str:
        return RegionSingletonFacet.make_pk()

    @handle_auth_exceptions
    def create(
        self, regions: Set[str] = None, do_overwrite=False
    ) -> RegionSingletonItem:
        item = RegionSingletonItem(regions)
        condition_expression = Attr("PK").not_exists() if not do_overwrite else ""
        try:
            # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.put_item
            response: PutItemOutputTableTypeDef = get_table_resource().put_item(
                Item={
                    "PK": self.make_pk(),
                    "SK": self.make_sk(),
                    self.ATTRIBUTES_MAP["item_type"]: self.ITEM_TYPE,
                    self.ATTRIBUTES_MAP["regions"]: regions,
                },
                # Do not overwrite.
                ConditionExpression=condition_expression,
                ReturnValues="NONE",
            )
        except get_table_resource().meta.client.exceptions.ConditionalCheckFailedException as exc:
            raise base_model_exceptions.PrimaryKeyConstraintError(item) from exc

        logger.debug("Response", extra=dict(response=response))
        return item

    @handle_auth_exceptions
    def delete(self) -> None:
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.delete_item
        response: DeleteItemOutputTableTypeDef = get_table_resource().delete_item(
            Key={"PK": self.make_pk(), "SK": self.make_sk()}
        )
        logger.debug("Response", extra=dict(response=response))

    @handle_auth_exceptions
    def read(self) -> RegionSingletonItem:
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.get_item
        response: GetItemOutputTableTypeDef = get_table_resource().get_item(
            Key={"PK": self.make_pk(), "SK": self.make_sk()}
        )
        logger.debug("Response", extra=dict(response=response))
        if not response.get("Item"):
            raise base_model_exceptions.ItemNotFound

        item = RegionSingletonItem.from_db(response["Item"])
        return item

    @handle_auth_exceptions
    def does_exist(self) -> bool:
        try:
            self.read()
        except base_model_exceptions.ItemNotFound:
            return False
        return True

    @handle_auth_exceptions
    def add_region(self, region: str) -> None:
        try:
            # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.update_item
            response: UpdateItemOutputTableTypeDef = get_table_resource().update_item(
                **self.make_update_expression(region)
            )
            logger.debug("Response", extra=dict(response=response))
        except get_table_resource().meta.client.exceptions.ConditionalCheckFailedException as exc:
            # The region already exists in RegionSingleton.regions, no action required.
            logger.info(f"Region already exists in RegionSingleton: {region}")
        except get_table_resource().meta.client.exceptions.ClientError as exc:
            if exc.response["Error"]["Code"] == "ValidationException":
                raise exceptions.RegionSingletonRegionsAttrNotAStringSet from exc
            raise

    @classmethod
    def make_update_expression(cls, region: str) -> dict:
        """
        Make an expression to be used with update_item() to add a region to the set
         RegionSingleton.Regions.
        """
        expression = {
            "Key": {"PK": cls.make_pk(), "SK": cls.make_sk()},
            # Note: if we add Attr("PK").not_exists() into ConditionExpression then
            #  when the condition expression fails, we would not be able to
            #  differentiate between the two expressions.
            "ConditionExpression": Not(
                Attr(cls.ATTRIBUTES_MAP["regions"]).contains(region)
            ),
            "UpdateExpression": "ADD #regions :region SET #item_type = :item_type",
            "ExpressionAttributeNames": {
                "#regions": cls.ATTRIBUTES_MAP["regions"],
                "#item_type": cls.ATTRIBUTES_MAP["item_type"],
            },
            "ExpressionAttributeValues": {
                ":region": {region},
                ":item_type": cls.ITEM_TYPE,
            },
            "ReturnValues": "NONE",
        }

        return expression
