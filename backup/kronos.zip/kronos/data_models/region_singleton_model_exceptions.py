class BaseRegionSingletonItemException(Exception):
    pass


class NotARegionSingletonItem(BaseRegionSingletonItemException):
    pass


class RegionSingletonRegionsAttrNotAStringSet(BaseRegionSingletonItemException):
    pass
