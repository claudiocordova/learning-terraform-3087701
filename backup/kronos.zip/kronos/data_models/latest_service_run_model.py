from datetime import datetime
from typing import TYPE_CHECKING, Iterator, Union

from boto3.dynamodb.conditions import And, Attr, Key
from ksuid import KsuidMs
from mypy_boto3_dynamodb.type_defs import (
    GetItemOutputTableTypeDef,
    PutItemOutputTableTypeDef,
)

from events.hdmap_services_events.hdmap_services_event_base import EventId, ServiceId

from ..conf import settings
from ..utils.boto3_utils import get_table_resource
from ..utils.log_utils import logger
from . import base_model_exceptions
from . import latest_service_run_model_exceptions as exceptions
from .base_model import ValidateEditableAttrsMixin, handle_auth_exceptions

# Trick to import from service_run only for the sake of type annotations and
#  avoiding the circular import, see: https://stackoverflow.com/a/39757388/17892029.
if TYPE_CHECKING:
    from .service_run_model import ServiceRunItem


class LatestServiceRunItem:
    def __init__(
        self,
        region: str,
        session: str,
        timestamp: datetime,
        # Eg. Ksuid("29eetkkR0Wv4Q5vnZJzsDxsXIWo").
        event_ksuid: KsuidMs,  # Required, unlike ServiceRunItem.
        event_id: str,  # Eg. SERVICE_STOP.
        event_source: str,  # Eg. MAP_RUNNER_JENKINS.
        service_id: str,  # Eg. MAP_RUNNER.
        service_progress_url: str,  # Eg. https://jenkins.ci.motional.com/job/MAP/job/map%252Fhdmap-services/job/feature%252FMapRunnerService/3089/.
        service_final_status: str = None,  # Eg. SUCCESS.
        service_error_message: str = None,  # Eg. Missing drivelog file.
        drivelog: str = None,  # Eg. 2022.02.16.18.48.56_g1p-veh-2042.
        is_test_data: bool = None,
        force_skip_subscribed_services: list = None,  # Eg. ["MAP_RASTERIZER", "MAP_GPKG_EXPORTER"] or ["*"] or ["*!", "MAP_RASTERIZER"].
        hdmap_slackbot: dict = None,  # Eg. {"extra_text": "Missing drivelog", "do_skip_notification": false}.
        slack_message: dict = None,  # {"text": "Hello world!", "channel": "test-slackbot-private"}.
        has_colored_point_cloud: bool = None,
    ):
        # TODO add validation (marshmallow?).
        self.item_type = LatestServiceRunFacet.ITEM_TYPE
        self.region = region
        self.session = session
        self.timestamp = timestamp
        self.event_ksuid = event_ksuid
        self.event_id = event_id
        self.event_source = event_source
        self.service_id = service_id
        self.service_progress_url = service_progress_url
        self.service_final_status = service_final_status
        self.service_error_message = service_error_message
        self.drivelog = drivelog
        self.is_test_data = is_test_data
        self.force_skip_subscribed_services = force_skip_subscribed_services
        self.hdmap_slackbot = hdmap_slackbot
        self.slack_message = slack_message
        self.has_colored_point_cloud = has_colored_point_cloud

    @property
    def pk(self):
        return LatestServiceRunFacet.make_pk(self.region, self.session)

    @property
    def sk(self):
        return LatestServiceRunFacet.make_sk(self.service_id)

    @classmethod
    def from_db(cls, data) -> "LatestServiceRunItem":
        if data.get("ItemType") != LatestServiceRunFacet.ITEM_TYPE:
            raise exceptions.NotALatestServiceRunItem

        item = cls(
            region=data.get(LatestServiceRunFacet.ATTRIBUTES_MAP["region"]),
            session=data.get(LatestServiceRunFacet.ATTRIBUTES_MAP["session"]),
            # It's in the SNS message automatically added by AWS.
            timestamp=datetime.fromisoformat(
                data.get(LatestServiceRunFacet.ATTRIBUTES_MAP["timestamp"])
            ),
            event_ksuid=KsuidMs.from_base62(
                data.get(LatestServiceRunFacet.ATTRIBUTES_MAP["event_ksuid"])
            ),
            event_id=data.get(LatestServiceRunFacet.ATTRIBUTES_MAP["event_id"]),
            event_source=data.get(LatestServiceRunFacet.ATTRIBUTES_MAP["event_source"]),
            service_id=data.get(LatestServiceRunFacet.ATTRIBUTES_MAP["service_id"]),
            service_progress_url=data.get(
                LatestServiceRunFacet.ATTRIBUTES_MAP["service_progress_url"]
            ),
            service_final_status=data.get(
                LatestServiceRunFacet.ATTRIBUTES_MAP["service_final_status"]
            ),
            service_error_message=data.get(
                LatestServiceRunFacet.ATTRIBUTES_MAP["service_error_message"]
            ),
            drivelog=data.get(LatestServiceRunFacet.ATTRIBUTES_MAP["drivelog"]),
            is_test_data=data.get(LatestServiceRunFacet.ATTRIBUTES_MAP["is_test_data"]),
            force_skip_subscribed_services=data.get(
                LatestServiceRunFacet.ATTRIBUTES_MAP["force_skip_subscribed_services"]
            ),
            hdmap_slackbot=data.get(
                LatestServiceRunFacet.ATTRIBUTES_MAP["hdmap_slackbot"]
            ),
            slack_message=data.get(
                LatestServiceRunFacet.ATTRIBUTES_MAP["slack_message"]
            ),
            has_colored_point_cloud=data.get(
                LatestServiceRunFacet.ATTRIBUTES_MAP["has_colored_point_cloud"]
            ),
        )
        item.item_type = data.get(LatestServiceRunFacet.ATTRIBUTES_MAP["item_type"])

        return item

    def to_dict(self):
        data = dict()
        for attr in sorted(
            set(LatestServiceRunFacet.ATTRIBUTES_MAP.keys()) - {"item_type"}
        ):
            value = getattr(self, attr)
            # Parse dates to strings.
            if isinstance(value, datetime):
                value = value.isoformat()
            if isinstance(value, KsuidMs):
                value = str(value)
            data[attr] = value
        # TODO remove this when we write these timestamps in the right format.
        #  Note that in this specific case, this is necessary only in tests.
        for attr in ("timestamp",):
            if data[attr] and not data[attr].endswith("+00:00"):
                data[attr] += "+00:00"
        return data


class LatestServiceRunFacet(ValidateEditableAttrsMixin):
    ITEM_TYPE = "LatestServiceRun"

    ATTRIBUTES_MAP = dict(
        # pk="PK",
        # sk="SK",
        item_type="ItemType",
        region="Region",
        session="Session",
        timestamp="Timestamp",
        event_ksuid="EventKsuid",
        event_id="EventId",
        event_source="EventSource",
        service_id="ServiceId",
        service_progress_url="ServiceProgressUrl",
        service_final_status="ServiceFinalStatus",
        service_error_message="ServiceErrorMessage",
        drivelog="Drivelog",
        is_test_data="IsTestData",
        force_skip_subscribed_services="ForceSkipSubscribedServices",
        hdmap_slackbot="HdmapSlackbot",
        slack_message="SlackMessage",
        has_colored_point_cloud="HasColoredPointCloud",
    )

    READ_ONLY_ATTRIBUTES: set = {
        "pk",
        "sk",
        "item_type",
        "region",
        "session",
    }
    EDITABLE_ATTRIBUTES: set = set(ATTRIBUTES_MAP.keys()) - set(READ_ONLY_ATTRIBUTES)

    def __init__(self, region: str, session: str):
        self.region = region
        self.session = session

    @staticmethod
    def make_pk(region: str, session: str) -> str:
        return f"DATASET#{region}|{session}"

    @staticmethod
    def make_sk(service_id: str) -> str:
        return f"LATESTSERVICERUN#{service_id}"

    @handle_auth_exceptions
    def create(
        self,
        timestamp: datetime,
        # Eg. Ksuid("29eetkkR0Wv4Q5vnZJzsDxsXIWo").
        event_ksuid: KsuidMs,  # Required, unlike ServiceRunItem.
        event_id: str,  # Eg. SERVICE_STOP.
        event_source: str,  # Eg. MAP_RUNNER_JENKINS.
        service_id: str,  # Eg. MAP_RUNNER.
        service_progress_url: str,
        do_overwrite=False,
        **attrs_to_create,
    ) -> LatestServiceRunItem:
        params = dict(
            **attrs_to_create,
            timestamp=timestamp,
            event_ksuid=event_ksuid,
            event_id=event_id,
            event_source=event_source,
            service_id=service_id,
            service_progress_url=service_progress_url,
        )
        all_keys = params.keys()

        # Validate attribute names.
        self._validate_editable_attributes(all_keys)

        item = LatestServiceRunItem(region=self.region, session=self.session, **params)
        condition_expression = Attr("PK").not_exists() if not do_overwrite else ""
        item_query = {
            "PK": item.pk,
            "SK": item.sk,
            self.ATTRIBUTES_MAP["item_type"]: item.item_type,
            self.ATTRIBUTES_MAP["region"]: item.region,
            self.ATTRIBUTES_MAP["session"]: item.session,
            self.ATTRIBUTES_MAP["event_ksuid"]: str(item.event_ksuid),
            self.ATTRIBUTES_MAP["timestamp"]: item.timestamp.isoformat(),
            self.ATTRIBUTES_MAP["event_id"]: item.event_id,
            self.ATTRIBUTES_MAP["event_source"]: item.event_source,
            self.ATTRIBUTES_MAP["service_id"]: item.service_id,
            self.ATTRIBUTES_MAP["service_progress_url"]: item.service_progress_url,
            self.ATTRIBUTES_MAP["service_final_status"]: item.service_final_status,
            self.ATTRIBUTES_MAP["service_error_message"]: item.service_error_message,
            self.ATTRIBUTES_MAP["drivelog"]: item.drivelog,
            self.ATTRIBUTES_MAP["is_test_data"]: item.is_test_data,
            self.ATTRIBUTES_MAP[
                "force_skip_subscribed_services"
            ]: item.force_skip_subscribed_services,
            self.ATTRIBUTES_MAP["hdmap_slackbot"]: item.hdmap_slackbot,
            self.ATTRIBUTES_MAP["slack_message"]: item.slack_message,
            self.ATTRIBUTES_MAP[
                "has_colored_point_cloud"
            ]: item.has_colored_point_cloud,
        }
        # Remove the None values.
        for key, value in {**item_query}.items():
            if value is None:
                del item_query[key]
        try:
            # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.put_item
            response: PutItemOutputTableTypeDef = get_table_resource().put_item(
                Item=item_query,
                # Do not overwrite.
                ConditionExpression=condition_expression,
                ReturnValues="NONE",
            )
        except get_table_resource().meta.client.exceptions.ConditionalCheckFailedException as exc:
            raise base_model_exceptions.PrimaryKeyConstraintError(item) from exc

        logger.debug("Response", extra=dict(response=response))
        return item

    @handle_auth_exceptions
    def read(
        self,
        service_id: str,
    ) -> LatestServiceRunItem:
        pk = self.make_pk(self.region, self.session)
        sk = self.make_sk(service_id)
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.put_item
        response: GetItemOutputTableTypeDef = get_table_resource().get_item(
            Key={"PK": pk, "SK": sk}
        )

        logger.debug("Response", extra=dict(response=response))
        if not response.get("Item"):
            raise base_model_exceptions.ItemNotFound

        item = LatestServiceRunItem.from_db(response["Item"])
        return item

    @handle_auth_exceptions
    def read_all_for_region_and_session(self) -> Iterator[LatestServiceRunItem]:
        pk = self.make_pk(self.region, self.session)
        sk = self.make_sk("")
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Paginator.Query
        paginator = get_table_resource().meta.client.get_paginator("query")
        response_iterator = paginator.paginate(
            TableName=settings.DYNAMODB_TABLE_NAME,
            Select="ALL_ATTRIBUTES",
            KeyConditionExpression=And(Key("PK").eq(pk), Key("SK").begins_with(sk)),
        )

        for response in response_iterator:
            logger.debug("Response", extra=dict(response=response))
            if not response.get("Items"):
                continue
            for item in response.get("Items"):
                yield LatestServiceRunItem.from_db(item)

    @classmethod
    def make_put_transaction_expression(
        cls, item: Union[LatestServiceRunItem, "ServiceRunItem"]
    ):
        """
        Make a dictionary that represents a transaction to be used with transact_write_items()
         to create LatestServiceRun.
        """
        # *RULE*: if it's a SERVICE_STOP event (for the same reg, sess, service_id),
        #  then we should OVERwrite the existing LatestServiceRunItem only
        #  if it has the same service_progress_url. Else, ignore.
        # That is because of this scenario:
        #  service GPKG_EXPORTER starts for reg1|ses1 > sends SERVICE_START|url1 > Mundi creates LatestServiceRun|reg1|ses1|GPKG(START,url1)
        #  service GPKG_EXPORTER starts again for reg1|ses1 > sends SERVICE_START|url2 > Mundi overwrites the existing with LatestServiceRun|reg1|ses1|GPKG(START,url2)
        #  service GPKG_EXPORTER job1 stops for reg1|ses1 > sends SERVICE_STOP|url1 > Mundi DOES NOT OVERWRITE the existing
        #  service GPKG_EXPORTER job2 stops for reg1|ses1 > sends SERVICE_STOP|url2 > Mundi OVERWRITES the existing with LatestServiceRun|reg1|ses1|GPKG(STOP,url2)
        condition_expression = ""  # Allow overwrites by default.
        expression_attribute_values = dict()
        # If service_id is CPG_TRANSFORMER, then no service_progress_url is provided, so don't add
        #  the condition expression.
        if (
            item.event_id == EventId.SERVICE_STOP.value
            and item.service_id != ServiceId.CPG_TRANSFORMER.value
        ):
            condition_expression = (
                "attribute_not_exists(PK) OR ServiceProgressUrl = :service_progress_url"
            )
            expression_attribute_values[
                ":service_progress_url"
            ] = item.service_progress_url

        transaction_op = {
            "Put": {
                "TableName": settings.DYNAMODB_TABLE_NAME,
                "Item": {
                    "PK": cls.make_pk(item.region, item.session),
                    "SK": cls.make_sk(item.service_id),
                    cls.ATTRIBUTES_MAP["item_type"]: cls.ITEM_TYPE,
                    cls.ATTRIBUTES_MAP["region"]: item.region,
                    cls.ATTRIBUTES_MAP["session"]: item.session,
                    cls.ATTRIBUTES_MAP["event_ksuid"]: str(item.event_ksuid),
                    cls.ATTRIBUTES_MAP["timestamp"]: item.timestamp.isoformat(),
                    cls.ATTRIBUTES_MAP["event_id"]: item.event_id,
                    cls.ATTRIBUTES_MAP["event_source"]: item.event_source,
                    cls.ATTRIBUTES_MAP["service_id"]: item.service_id,
                    cls.ATTRIBUTES_MAP[
                        "service_progress_url"
                    ]: item.service_progress_url,
                    cls.ATTRIBUTES_MAP[
                        "service_final_status"
                    ]: item.service_final_status,
                    cls.ATTRIBUTES_MAP[
                        "service_error_message"
                    ]: item.service_error_message,
                    cls.ATTRIBUTES_MAP["drivelog"]: item.drivelog,
                    cls.ATTRIBUTES_MAP["is_test_data"]: item.is_test_data,
                    cls.ATTRIBUTES_MAP[
                        "force_skip_subscribed_services"
                    ]: item.force_skip_subscribed_services,
                    cls.ATTRIBUTES_MAP["hdmap_slackbot"]: item.hdmap_slackbot,
                    cls.ATTRIBUTES_MAP["slack_message"]: item.slack_message,
                    cls.ATTRIBUTES_MAP[
                        "has_colored_point_cloud"
                    ]: item.has_colored_point_cloud,
                },
                # "ConditionExpression": condition_expression,
                # "ExpressionAttributeValues": expression_attribute_values,
                "ReturnValuesOnConditionCheckFailure": "NONE",
            }
        }
        if condition_expression or settings.IS_TEST:
            # For some reasons this works differently in prod with actual DynamoDB and
            #  in test with moto mocks.
            transaction_op["Put"]["ConditionExpression"] = condition_expression
        if expression_attribute_values or settings.IS_TEST:
            # For some reasons this works differently in prod with actual DynamoDB and
            #  in test with moto mocks.
            transaction_op["Put"][
                "ExpressionAttributeValues"
            ] = expression_attribute_values

        # Remove the None values.
        for key, value in {**transaction_op["Put"]["Item"]}.items():
            if value is None:
                del transaction_op["Put"]["Item"][key]
        return transaction_op
