class BaseDataModelsException(Exception):
    pass


class PrimaryKeyConstraintError(BaseDataModelsException):
    def __init__(self, item):
        self.item = item


class ItemNotFound(BaseDataModelsException):
    pass


class AuthError(BaseDataModelsException):
    pass


class UnknownAttribute(BaseDataModelsException):
    def __init__(self, attr_name):
        self.attr_name = attr_name


class ReadOnlyAttribute(BaseDataModelsException):
    def __init__(self, attr_name):
        self.attr_name = attr_name


class NotNullableGsi(BaseDataModelsException):
    pass


class StartingTokenPaginationError(BaseDataModelsException):
    pass


class PaginationError(BaseDataModelsException):
    pass
