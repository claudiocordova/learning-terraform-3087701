class BaseDatasetSummaryItemException(Exception):
    pass


class NotADatasetSummaryItem(BaseDatasetSummaryItemException):
    pass
