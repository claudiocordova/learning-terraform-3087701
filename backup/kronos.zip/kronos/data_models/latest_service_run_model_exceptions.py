class BaseLatestServiceRunException(Exception):
    pass


class NotALatestServiceRunItem(BaseLatestServiceRunException):
    pass
