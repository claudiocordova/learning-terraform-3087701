from datetime import datetime
from typing import Iterator, Optional

from boto3.dynamodb.conditions import Key

from ..conf import settings
from ..utils import boto3_utils
from ..utils.dynamodb_utils import PaginatedResponse, dynamize, get_pagination_config
from . import dataset_summary_model_exceptions as exceptions
from .base_model import handle_auth_exceptions, handle_pagination_exceptions
from .dataset_model import (
    DatasetItem,
    GsiDatasetSummaryConst,
    GsiDatasetSummaryPerDrivelogConst,
    GsiDatasetSummaryPerEnvConst,
)


class DatasetSummaryItem:
    def __init__(
        self,
        region: str,
        session: str,
        environment: str = None,
        services_status: str = None,
        artifacts_status: str = None,
        last_service_run_at: datetime = None,
        drivelog: str = None,
        operation_type: str = None,
        has_colored_point_cloud: bool = None,
        do_send_slack_notification_on_service_status_success: bool = None,
    ):
        # TODO add validation (marshmallow?).
        self.item_type = DatasetSummaryFacet.ITEM_TYPE
        self.region = region
        self.session = session
        self.environment = environment
        self.services_status = services_status
        self.artifacts_status = artifacts_status
        self.last_service_run_at = last_service_run_at
        self.drivelog = drivelog
        self.operation_type = operation_type
        self.created_at = None
        self.updated_at = None
        self.has_colored_point_cloud = has_colored_point_cloud
        self.do_send_slack_notification_on_service_status_success = (
            do_send_slack_notification_on_service_status_success
        )

    @classmethod
    def from_db(cls, data) -> "DatasetSummaryItem":
        if data.get("ItemType") != DatasetSummaryFacet.ITEM_TYPE:
            raise exceptions.NotADatasetSummaryItem

        item = cls(
            region=data.get(dynamize("region")),
            session=data.get(dynamize("session")),
            environment=data.get(dynamize("environment")),
            services_status=data.get(dynamize("services_status")),
            artifacts_status=data.get(dynamize("artifacts_status")),
            drivelog=data.get(dynamize("drivelog")),
            operation_type=data.get(dynamize("operation_type")),
            has_colored_point_cloud=data.get(dynamize("has_colored_point_cloud")),
            do_send_slack_notification_on_service_status_success=data.get(
                dynamize("do_send_slack_notification_on_service_status_success")
            ),
        )
        item.item_type = data.get(dynamize("item_type"))

        last_service_run_at: Optional[str] = data.get(dynamize("last_service_run_at"))
        if last_service_run_at:
            item.last_service_run_at = datetime.fromisoformat(last_service_run_at)

        item.created_at = data.get(dynamize("created_at"))
        if item.created_at:
            item.created_at = datetime.fromisoformat(item.created_at)

        item.updated_at = data.get(dynamize("updated_at"))
        if item.updated_at:
            item.updated_at = datetime.fromisoformat(item.updated_at)

        return item

    @classmethod
    def from_dataset_item(cls, dataset_item: DatasetItem) -> "DatasetSummaryItem":
        item = cls(
            region=dataset_item.region,
            session=dataset_item.session,
        )
        for attr in DatasetSummaryFacet.NON_KEY_ATTRS:
            value = getattr(dataset_item, attr)
            setattr(item, attr, value)
        item.item_type = DatasetSummaryFacet.ITEM_TYPE
        return item

    def to_dict(self):
        # TODO this should return all attrs. Maybe make it parametric such that the
        #  views can use it to return only some.
        data = dict()
        for attr in sorted(DatasetSummaryFacet.NON_KEY_ATTRS - {"item_type"}):
            value = getattr(self, attr)
            # Parse dates to strings.
            if isinstance(value, datetime):
                value = value.isoformat()
            data[attr] = value
        # TODO remove this when we write these timestamps in the right format.
        for attr in ("created_at", "updated_at", "last_service_run_at"):
            if data[attr] and not data[attr].endswith("+00:00"):
                data[attr] += "+00:00"
        return data

    def __str__(self):
        return f"{self.__class__.__name__}|{self.region}|{self.session}"

    def __repr__(self):
        return f"<{self.__class__.__module__}.{self.__class__.__name__}|{self.region}|{self.session}>"


class DatasetSummaryFacet:
    ITEM_TYPE = "Dataset"

    NON_KEY_ATTRS: set = {
        "item_type",
        "created_at",
        "updated_at",
        "region",
        "session",
        "environment",
        "services_status",
        "artifacts_status",
        "last_service_run_at",
        "drivelog",
        "operation_type",
        "has_colored_point_cloud",
        "do_send_slack_notification_on_service_status_success",
    }
    KEY_ATTRS: set = {"pk", "sk"}
    ALL_ATTRS: set = {
        *KEY_ATTRS,
        *NON_KEY_ATTRS,
    }

    @handle_auth_exceptions
    @handle_pagination_exceptions
    def read_all(
        self,
        do_read_all_items=False,
        starting_token: Optional[str] = None,
    ) -> "DatasetSummaryPaginatedResponse":
        pagination_config = get_pagination_config(
            do_read_all_items=do_read_all_items, starting_token=starting_token
        )
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Paginator.Query
        paginator = boto3_utils.get_table_resource().meta.client.get_paginator("query")
        response_iterator = paginator.paginate(
            TableName=settings.DYNAMODB_TABLE_NAME,
            IndexName=GsiDatasetSummaryConst.NAME,
            Select="SPECIFIC_ATTRIBUTES",
            ProjectionExpression=", ".join(f"#{x}" for x in self.ALL_ATTRS),
            ExpressionAttributeNames={f"#{x}": dynamize(x) for x in self.ALL_ATTRS},
            KeyConditionExpression=Key(dynamize(GsiDatasetSummaryConst.PK_ATTR)).eq(
                "DATASETSUMMARIES"
            ),
            ScanIndexForward=False,  # Reverse sorting.
            PaginationConfig=pagination_config,
        )
        return DatasetSummaryPaginatedResponse(response_iterator)

    @handle_auth_exceptions
    @handle_pagination_exceptions
    def read_all_for_environment(
        self,
        environment: str,
        do_read_all_items=False,
        starting_token: Optional[str] = None,
    ) -> "DatasetSummaryPaginatedResponse":
        pagination_config = get_pagination_config(
            do_read_all_items=do_read_all_items, starting_token=starting_token
        )
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Paginator.Query
        paginator = boto3_utils.get_table_resource().meta.client.get_paginator("query")
        response_iterator = paginator.paginate(
            TableName=settings.DYNAMODB_TABLE_NAME,
            IndexName=GsiDatasetSummaryPerEnvConst.NAME,
            Select="SPECIFIC_ATTRIBUTES",
            ProjectionExpression=", ".join(f"#{x}" for x in self.ALL_ATTRS),
            ExpressionAttributeNames={f"#{x}": dynamize(x) for x in self.ALL_ATTRS},
            KeyConditionExpression=Key(
                dynamize(GsiDatasetSummaryPerEnvConst.PK_ATTR)
            ).eq(f"DATASETSUMMARIES#ENV#{environment}".upper()),
            ScanIndexForward=False,  # Reverse sorting.
            PaginationConfig=pagination_config,
        )
        return DatasetSummaryPaginatedResponse(response_iterator)

    @handle_auth_exceptions
    @handle_pagination_exceptions
    def read_all_for_region(self) -> Iterator[DatasetSummaryItem]:
        # TODO BAS-2543.
        raise NotImplementedError

    @handle_auth_exceptions
    @handle_pagination_exceptions
    def read_all_for_drivelog(
        self,
        drivelog: str,
        do_read_all_items=False,
        starting_token: Optional[str] = None,
    ) -> "DatasetSummaryPaginatedResponse":
        pagination_config = get_pagination_config(
            do_read_all_items=do_read_all_items, starting_token=starting_token
        )
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Paginator.Query
        paginator = boto3_utils.get_table_resource().meta.client.get_paginator("query")
        response_iterator = paginator.paginate(
            TableName=settings.DYNAMODB_TABLE_NAME,
            IndexName=GsiDatasetSummaryPerDrivelogConst.NAME,
            Select="SPECIFIC_ATTRIBUTES",
            ProjectionExpression=", ".join(f"#{x}" for x in self.ALL_ATTRS),
            ExpressionAttributeNames={f"#{x}": dynamize(x) for x in self.ALL_ATTRS},
            KeyConditionExpression=Key(
                dynamize(GsiDatasetSummaryPerDrivelogConst.PK_ATTR)
            ).eq(f"DATASETSUMMARIES#DRIVELOG#{drivelog}".upper()),
            ScanIndexForward=False,  # Reverse sorting.
            PaginationConfig=pagination_config,
        )
        return DatasetSummaryPaginatedResponse(response_iterator)


class DatasetSummaryPaginatedResponse(PaginatedResponse):
    @property
    def items(self) -> Iterator[DatasetSummaryItem]:
        for item in self.full_result.get("Items"):
            yield DatasetSummaryItem.from_db(item)
