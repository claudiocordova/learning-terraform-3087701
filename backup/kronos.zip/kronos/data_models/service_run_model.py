from datetime import datetime
from typing import Iterator, Optional, Union

from boto3.dynamodb.conditions import And, Attr, Key
from ksuid import KsuidMs
from mypy_boto3_dynamodb.type_defs import (
    GetItemOutputTableTypeDef,
    PutItemOutputTableTypeDef,
    TransactWriteItemTypeDef,
)

from ..conf import settings
from ..utils import time_utils
from ..utils.boto3_utils import get_table_resource
from ..utils.dynamodb_utils import (
    dynamize,
    get_pagination_config,
    serialize_to_dynamodb,
)
from ..utils.log_utils import logger
from . import base_model_exceptions, region_singleton_model_exceptions
from . import service_run_model_exceptions as exceptions
from .base_model import ValidateEditableAttrsMixin, handle_auth_exceptions
from .dataset_model import DatasetFacet
from .latest_service_run_model import LatestServiceRunFacet
from .region_singleton_model import RegionSingletonFacet


class GsiServiceRunPerDrivelogConst:
    NAME = "GSIServiceRunPerDrivelog"
    PK_ATTR = "gsi_service_run_per_drivelog_pk_drivelog"
    IS_PK_NULLABLE = True
    PK_BOUND_ATTRS = ("drivelog",)
    SK_ATTR = "gsi_service_run_per_drivelog_sk_timestamp"
    IS_SK_NULLABLE = False
    SK_BOUND_ATTRS = ("timestamp",)
    PROJECTION_TYPE = "ALL"


class ServiceRunItem:
    def __init__(
        self,
        region: str,
        session: str,
        timestamp: datetime,
        event_id: str,  # Eg. SERVICE_STOP.
        event_source: str,  # Eg. MAP_RUNNER_JENKINS.
        service_id: str,  # Eg. MAP_RUNNER.
        service_progress_url: str,  # Eg. https://jenkins.ci.motional.com/job/MAP/job/map%252Fhdmap-services/job/feature%252FMapRunnerService/3089/.
        # Eg. Ksuid("29eetkkR0Wv4Q5vnZJzsDxsXIWo").
        event_ksuid: Optional[KsuidMs] = None,
        service_final_status: str = None,  # Eg. SUCCESS.
        service_error_message: str = None,  # Eg. Missing drivelog file.
        drivelog: str = None,  # Eg. 2022.02.16.18.48.56_g1p-veh-2042.
        is_test_data: bool = None,
        force_skip_subscribed_services: list = None,  # Eg. ["MAP_RASTERIZER", "MAP_GPKG_EXPORTER"] or ["*"] or ["*!", "MAP_RASTERIZER"].
        hdmap_slackbot: dict = None,  # Eg. {"extra_text": "Missing drivelog", "do_skip_notification": false}.
        slack_message: dict = None,  # {"text": "Hello world!", "channel": "test-slackbot-private"}.
        has_colored_point_cloud: bool = None,
    ):
        # TODO add validation (marshmallow?).
        self.item_type = ServiceRunFacet.ITEM_TYPE
        self.region = region
        self.session = session
        self.timestamp = timestamp
        self.event_id = event_id
        self.event_source = event_source
        self.service_id = service_id
        self.service_progress_url = service_progress_url
        self.service_final_status = service_final_status
        self.service_error_message = service_error_message
        self.drivelog = drivelog
        self.is_test_data = is_test_data
        self.force_skip_subscribed_services = force_skip_subscribed_services
        self.hdmap_slackbot = hdmap_slackbot
        self.slack_message = slack_message
        self.has_colored_point_cloud = has_colored_point_cloud

        self.event_ksuid = event_ksuid
        # Ensure the ksuid exists because it is part of sk.
        if not self.event_ksuid:
            self.event_ksuid = KsuidMs(time_utils.now())

    @property
    def pk(self):
        return ServiceRunFacet.make_pk(self.region, self.session)

    @property
    def sk(self):
        return ServiceRunFacet.make_sk(self.service_id, self.event_ksuid)

    @classmethod
    def from_db(cls, data) -> "ServiceRunItem":
        if data.get("ItemType") != ServiceRunFacet.ITEM_TYPE:
            raise exceptions.NotAServiceRunItem

        item = cls(
            region=data.get(ServiceRunFacet.ATTRIBUTES_MAP["region"]),
            session=data.get(ServiceRunFacet.ATTRIBUTES_MAP["session"]),
            # It's in the SNS message automatically added by AWS.
            timestamp=datetime.fromisoformat(
                data.get(ServiceRunFacet.ATTRIBUTES_MAP["timestamp"])
            ),
            event_ksuid=KsuidMs.from_base62(
                data.get(ServiceRunFacet.ATTRIBUTES_MAP["event_ksuid"])
            ),
            event_id=data.get(ServiceRunFacet.ATTRIBUTES_MAP["event_id"]),
            event_source=data.get(ServiceRunFacet.ATTRIBUTES_MAP["event_source"]),
            service_id=data.get(ServiceRunFacet.ATTRIBUTES_MAP["service_id"]),
            service_progress_url=data.get(
                ServiceRunFacet.ATTRIBUTES_MAP["service_progress_url"]
            ),
            service_final_status=data.get(
                ServiceRunFacet.ATTRIBUTES_MAP["service_final_status"]
            ),
            service_error_message=data.get(
                ServiceRunFacet.ATTRIBUTES_MAP["service_error_message"]
            ),
            drivelog=data.get(ServiceRunFacet.ATTRIBUTES_MAP["drivelog"]),
            is_test_data=data.get(ServiceRunFacet.ATTRIBUTES_MAP["is_test_data"]),
            force_skip_subscribed_services=data.get(
                ServiceRunFacet.ATTRIBUTES_MAP["force_skip_subscribed_services"]
            ),
            hdmap_slackbot=data.get(ServiceRunFacet.ATTRIBUTES_MAP["hdmap_slackbot"]),
            slack_message=data.get(ServiceRunFacet.ATTRIBUTES_MAP["slack_message"]),
            has_colored_point_cloud=data.get(
                ServiceRunFacet.ATTRIBUTES_MAP["has_colored_point_cloud"]
            ),
        )
        item.item_type = data.get(ServiceRunFacet.ATTRIBUTES_MAP["item_type"])

        return item

    @property
    def gsi_service_run_per_drivelog_pk_drivelog(self):
        # This GSI can be sparse (so None values will not be part of the index).
        if self.drivelog:
            return f"SERVICERUN#DRIVELOG#{self.drivelog}".upper()

    @property
    def gsi_service_run_per_drivelog_sk_timestamp(self):
        return serialize_to_dynamodb(self.timestamp)

    def to_dict(self):
        data = dict()
        for attr in sorted(set(ServiceRunFacet.ATTRIBUTES_MAP.keys()) - {"item_type"}):
            value = getattr(self, attr)
            # Parse dates to strings.
            if isinstance(value, datetime):
                value = value.isoformat()
            if isinstance(value, KsuidMs):
                value = str(value)
            data[attr] = value
        # TODO remove this when we write these timestamps in the right format.
        #  Note that in this specific case, this is necessary only in tests.
        for attr in ("timestamp",):
            if data[attr] and not data[attr].endswith("+00:00"):
                data[attr] += "+00:00"
        return data


class ServiceRunFacet(ValidateEditableAttrsMixin):
    ITEM_TYPE = "ServiceRun"

    ALL_INDEXES: set = {
        GsiServiceRunPerDrivelogConst,
    }

    ATTRIBUTES_MAP = dict(
        # pk="PK",
        # sk="SK",
        item_type="ItemType",
        region="Region",
        session="Session",
        timestamp="Timestamp",
        event_ksuid="EventKsuid",
        event_id="EventId",
        event_source="EventSource",
        service_id="ServiceId",
        service_progress_url="ServiceProgressUrl",
        service_final_status="ServiceFinalStatus",
        service_error_message="ServiceErrorMessage",
        drivelog="Drivelog",
        is_test_data="IsTestData",
        force_skip_subscribed_services="ForceSkipSubscribedServices",
        hdmap_slackbot="HdmapSlackbot",
        slack_message="SlackMessage",
        has_colored_point_cloud="HasColoredPointCloud",
    )

    READ_ONLY_ATTRIBUTES: set = {
        "pk",
        "sk",
        "item_type",
        "region",
        "session",
        "event_ksuid",
    }
    EDITABLE_ATTRIBUTES: set = set(ATTRIBUTES_MAP.keys()) - set(READ_ONLY_ATTRIBUTES)

    def __init__(self, region: Optional[str] = None, session: Optional[str] = None):
        self.region = region
        self.session = session

    @staticmethod
    def make_pk(region: Optional[str], session: Optional[str]) -> str:
        if region is None:
            region = "NONE"
        if session is None:
            session = "NONE"
        return f"DATASET#{region}|{session}"

    @staticmethod
    def make_sk(service_id: str, event_ksuid: Union[str, KsuidMs]) -> str:
        return f"SERVICE#{service_id}#SERVICERUN#{event_ksuid}"

    @handle_auth_exceptions
    def create(
        self,
        timestamp: datetime,
        event_id: str,  # Eg. SERVICE_STOP.
        event_source: str,  # Eg. MAP_RUNNER_JENKINS.
        service_id: str,  # Eg. MAP_RUNNER.
        service_progress_url: str,
        # Use this to avoid creating or updating LatestServiceRun, Dataset and RegionSingleton.
        do_skip_side_effects=False,
        # `event_ksuid` cannot be passed as `attrs_to_create`, but it is auto-generated.
        # Use `do_force_event_ksuid` to overwrite this behavior in tests and allow
        # passing `event_ksuid` in `attrs_to_create`.
        do_force_event_ksuid=False,
        **attrs_to_create,
    ) -> ServiceRunItem:
        """
        Create a new ServiceRun and:
         - update RegionSingleton.regions;
         - create (and overwrite if existing) of LatestServiceRun item;
         - update Dataset.LastServiceRunAt if Dataset exists; if it does not
            exist then create it with basic info.
        """
        if not timestamp:
            raise exceptions.TimestampMissing

        params = dict(
            **attrs_to_create,
            timestamp=timestamp,
            event_id=event_id,
            event_source=event_source,
            service_id=service_id,
            service_progress_url=service_progress_url,
        )
        # Validate attribute names but remove `event_ksuid` if `do_force_event_ksuid`.
        all_keys = params.keys()
        if do_force_event_ksuid:
            all_keys = (x for x in params.keys() if x != "event_ksuid")
        try:
            self._validate_editable_attributes(all_keys)
        except (
            base_model_exceptions.ReadOnlyAttribute,
            base_model_exceptions.UnknownAttribute,
        ):
            raise

        item = ServiceRunItem(region=self.region, session=self.session, **params)
        # 1st operation (not a transaction): create the ServiceRun.
        try:
            # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.put_item
            response: PutItemOutputTableTypeDef = get_table_resource().put_item(
                **self.make_put_if_not_existing_expression(item)
            )
        except get_table_resource().meta.client.exceptions.ConditionalCheckFailedException as exc:
            raise base_model_exceptions.PrimaryKeyConstraintError(item) from exc

        if do_skip_side_effects:
            return item

        # The next operations can fail, but we still want to execute all of them without
        #  stopping at the first error. So we collect exceptions here and raise at the end.
        collected_exceptions = list()

        # 2nd operation (not a transaction): update RegionSingleton.regions.
        # Not doing this in a transaction because that leads to TransactionConflict
        #  errors when in the S3Bucket Scanner more Lambdas concurrently update
        #  RegionSingleton.regions.
        try:
            RegionSingletonFacet().add_region(self.region)
        except region_singleton_model_exceptions.RegionSingletonRegionsAttrNotAStringSet as exc:
            logger.exception("RegionSingletonFacet.add_region failed")
            # Store the exception and continue, re-raise it later.
            collected_exceptions.append(exc)

        # 3rd operation, transaction:
        #   a. Create (and overwrite if existing) LatestServiceRun.
        #   b. Update Dataset.LastServiceRunAt. Actually the operation to
        #       perform is:
        #         if Dataset exists: update Dataset.LastServiceRunAt
        #         if Dataset does not exist: create it with basic info.
        #      Which can be simplified to always create or update the basic info.
        latest_service_run_item_transaction_op = (
            LatestServiceRunFacet.make_put_transaction_expression(item)
        )
        # Notice that if `latest_service_run_item_transaction_op` fails likely it is
        #  because LatestServiceRun already exists (and event_id is "SERVICE_STOP"
        #  and service_progress_url is different from the existing) so also
        #  the Dataset already exists.
        dataset_item_transaction_op = DatasetFacet.make_create_or_update_expression(
            region=self.region,
            session=self.session,
            attrs_to_update=dict(
                last_service_run_at=timestamp,
                has_colored_point_cloud=params.get("has_colored_point_cloud"),
            ),
            is_transaction=True,
        )
        try:
            # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Client.transact_write_items
            response: TransactWriteItemTypeDef = get_table_resource().meta.client.transact_write_items(
                # Note: TransactItems accepts only list, not tuple.
                TransactItems=[
                    latest_service_run_item_transaction_op,
                    dataset_item_transaction_op,
                ]
            )
        except get_table_resource().meta.client.exceptions.TransactionCanceledException as exc:
            # The exception looks like this:
            # "An error occurred (TransactionCanceledException) when calling the TransactWriteItems operation: Transaction cancelled, please refer cancellation reasons for specific reasons [ConditionalCheckFailed, None]".
            if "[ConditionalCheckFailed" in exc.args[0]:
                # The 1st operation in the transaction has failed.
                # It means that the condition_expression has failed: we received a
                #  SERVICE_STOP event for an url diff than the existing LatestServiceRun
                #  for the same region, session, service_id. So we can safely ignore this.
                logger.info(
                    "Cannot update an existing LatestServiceRun when event_id is SERVICE_STOP"
                    " and service_progress_url is different than the existing"
                )
            else:
                logger.exception("Transaction failed")
                collected_exceptions.append(exc)
        logger.debug("Response", extra=dict(response=response))

        if collected_exceptions:
            logger.error(
                "Collected exceptions", extra=dict(exceptions=collected_exceptions)
            )
            # Raise the first exception only.
            raise collected_exceptions[0]

        return item

    @handle_auth_exceptions
    def read(self, service_id: str, event_ksuid: Union[str, KsuidMs]) -> ServiceRunItem:
        pk = self.make_pk(self.region, self.session)
        sk = self.make_sk(service_id, event_ksuid)
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.put_item
        response: GetItemOutputTableTypeDef = get_table_resource().get_item(
            Key={"PK": pk, "SK": sk}
        )

        logger.debug("Response", extra=dict(response=response))
        if not response.get("Item"):
            raise base_model_exceptions.ItemNotFound

        item = ServiceRunItem.from_db(response["Item"])
        return item

    @handle_auth_exceptions
    def read_all_for_region_and_session_and_service_id(
        self,
        service_id: str,
        do_read_all_items=False,
    ) -> Iterator[ServiceRunItem]:
        pk = self.make_pk(self.region, self.session)
        sk = self.make_sk(service_id, "")
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Paginator.Query
        pagination_config = get_pagination_config(do_read_all_items=do_read_all_items)
        paginator = get_table_resource().meta.client.get_paginator("query")
        response_iterator = paginator.paginate(
            TableName=settings.DYNAMODB_TABLE_NAME,
            Select="ALL_ATTRIBUTES",
            KeyConditionExpression=And(Key("PK").eq(pk), Key("SK").begins_with(sk)),
            ScanIndexForward=False,  # Reverse sorting.
            PaginationConfig=pagination_config,
        )

        for response in response_iterator:
            logger.debug("Response", extra=dict(response=response))
            if not response.get("Items"):
                continue
            for item in response.get("Items"):
                yield ServiceRunItem.from_db(item)

    # TODO BAS-2515 test this.
    @handle_auth_exceptions
    def read_all_for_region_and_session(self) -> Iterator[ServiceRunItem]:
        pk = self.make_pk(self.region, self.session)
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Paginator.Query
        paginator = get_table_resource().meta.client.get_paginator("query")
        response_iterator = paginator.paginate(
            TableName=settings.DYNAMODB_TABLE_NAME,
            Select="ALL_ATTRIBUTES",
            KeyConditionExpression=And(
                Key("PK").eq(pk), Key("SK").begins_with("SERVICE#")
            ),
            ScanIndexForward=False,  # Reverse sorting.
            PaginationConfig=get_pagination_config(do_read_all_items=True),
        )

        for response in response_iterator:
            logger.debug("Response", extra=dict(response=response))
            if not response.get("Items"):
                continue
            for item in response.get("Items"):
                yield ServiceRunItem.from_db(item)

    @staticmethod
    @handle_auth_exceptions
    def read_all_for_drivelog(
        drivelog: str,
        do_read_all_items=False,
    ) -> Iterator[ServiceRunItem]:
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Paginator.Query
        pagination_config = get_pagination_config(do_read_all_items=do_read_all_items)
        paginator = get_table_resource().meta.client.get_paginator("query")
        response_iterator = paginator.paginate(
            TableName=settings.DYNAMODB_TABLE_NAME,
            IndexName=GsiServiceRunPerDrivelogConst.NAME,
            Select="ALL_ATTRIBUTES",
            KeyConditionExpression=Key(
                dynamize(GsiServiceRunPerDrivelogConst.PK_ATTR)
            ).eq(f"SERVICERUN#DRIVELOG#{drivelog}".upper()),
            ScanIndexForward=False,  # Reverse sorting.
            PaginationConfig=pagination_config,
        )

        for response in response_iterator:
            logger.debug("Response", extra=dict(response=response))
            if not response.get("Items"):
                continue
            for item in response.get("Items"):
                yield ServiceRunItem.from_db(item)

    @classmethod
    def make_put_if_not_existing_expression(cls, item: ServiceRunItem) -> dict:
        """
        Make a dictionary that represents an operation to be used with put_item()
         to create ServiceRun.
        """
        expression = {
            "Item": {
                "PK": item.pk,
                "SK": item.sk,
                # TODO refactor this using a for loop on ALL_ATTRS or similar (plus dynamize).
                dynamize("item_type"): item.item_type,
                dynamize("region"): item.region,
                dynamize("session"): item.session,
                dynamize("event_ksuid"): str(item.event_ksuid),
                dynamize("timestamp"): item.timestamp.isoformat(),
                dynamize("event_id"): item.event_id,
                dynamize("event_source"): item.event_source,
                dynamize("service_id"): item.service_id,
                dynamize("service_progress_url"): item.service_progress_url,
                dynamize("service_final_status"): item.service_final_status,
                dynamize("service_error_message"): item.service_error_message,
                dynamize("drivelog"): item.drivelog,
                dynamize("is_test_data"): item.is_test_data,
                dynamize(
                    "force_skip_subscribed_services"
                ): item.force_skip_subscribed_services,
                dynamize("hdmap_slackbot"): item.hdmap_slackbot,
                dynamize("slack_message"): item.slack_message,
                dynamize("has_colored_point_cloud"): item.has_colored_point_cloud,
                dynamize(
                    "gsi_service_run_per_drivelog_pk_drivelog"
                ): item.gsi_service_run_per_drivelog_pk_drivelog,
                dynamize(
                    "gsi_service_run_per_drivelog_sk_timestamp"
                ): item.gsi_service_run_per_drivelog_sk_timestamp,
            },
            # Do not overwrite.
            "ConditionExpression": Attr("PK").not_exists(),
            "ReturnValues": "NONE",
        }

        # Remove the None values.
        for key, value in {**expression["Item"]}.items():
            if value is None:
                del expression["Item"][key]
        return expression
    
