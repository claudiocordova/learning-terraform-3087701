from boto3.dynamodb.conditions import Key

from ..conf import settings
from ..utils import boto3_utils
from ..utils.dynamodb_utils import dynamize
from ..utils.log_utils import logger
from .base_model import handle_auth_exceptions
from .base_model_exceptions import ItemNotFound
from .dataset_model import GsiSessionConst


class SessionFacet:
    @handle_auth_exceptions
    def read(self, region: str) -> str:
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Paginator.Query
        paginator = boto3_utils.get_table_resource().meta.client.get_paginator("query")
        # TODO catch exception when I don't filter by PK
        #  and when Select is set to ALL_ATTRIBUTES but projection not set to ALL.
        response_iterator = paginator.paginate(
            TableName=settings.DYNAMODB_TABLE_NAME,
            IndexName=GsiSessionConst.NAME,
            # Select="ALL_PROJECTED_ATTRIBUTES",
            KeyConditionExpression=Key(dynamize(GsiSessionConst.PK_ATTR)).eq(
                f"{region}"
            ),
        )

        for response in response_iterator:
            logger.debug("Response", extra=dict(response=response))
            if not response.get("Items"):
                raise ItemNotFound
            for item in response.get("Items"):
                yield item.get(dynamize(GsiSessionConst.SK_ATTR))
