class BaseDatasetItemException(Exception):
    pass


class NotADatasetItem(BaseDatasetItemException):
    pass
