import functools

from botocore import exceptions as botocore_exceptions

from ..utils import dynamodb_utils_exceptions
from . import base_model_exceptions as exceptions


def handle_auth_exceptions(fn):
    @functools.wraps(fn)
    def closure(*fn_args, **fn_kwargs):
        # `self` in the original method, if the decorated fn is a method.
        # zelf = fn_args[0]
        try:
            return fn(*fn_args, **fn_kwargs)
        except botocore_exceptions.NoCredentialsError as exc:
            raise exceptions.AuthError from exc
        except botocore_exceptions.ClientError as exc:
            if "ExpiredTokenException" in exc.response.get("Error", {}).get(
                "Code", ""
            ) or "ExpiredTokenException" in str(exc):
                raise exceptions.AuthError from exc
            raise

    return closure


def handle_pagination_exceptions(fn):
    @functools.wraps(fn)
    def closure(*fn_args, **fn_kwargs):
        # `self` in the original method, if the decorated fn is a method.
        # zelf = fn_args[0]
        try:
            return fn(*fn_args, **fn_kwargs)
        except dynamodb_utils_exceptions.StartingTokenPaginationConfigError as exc:
            raise exceptions.StartingTokenPaginationError from exc
        except dynamodb_utils_exceptions.PaginationConfigError as exc:
            raise exceptions.PaginationError from exc

    return closure


class ValidateEditableAttrsMixin:
    ATTRIBUTES_MAP = dict()
    ALL_ATTRS = dict()
    READ_ONLY_ATTRS = set()

    @classmethod
    def _validate_editable_attributes(cls, attributes):
        for key in attributes:
            if key in cls.READ_ONLY_ATTRS:
                raise exceptions.ReadOnlyAttribute(key)
            # TODO simplify this line when we delete all ATTRIBUTES_MAP.
            all_attrs = getattr(cls, "ATTRIBUTES_MAP") or cls.ALL_ATTRS
            if key not in all_attrs:
                raise exceptions.UnknownAttribute(key)
