from datetime import datetime
from enum import Enum
from typing import Optional

from boto3.dynamodb.conditions import Attr
from mypy_boto3_dynamodb.type_defs import (
    GetItemOutputTableTypeDef,
    PutItemOutputTableTypeDef,
    UpdateItemOutputTableTypeDef,
)

from events.hdmap_services_events.hdmap_services_event_base import ServiceId

from ..conf import settings
from ..utils import dynamodb_utils, time_utils
from ..utils.boto3_utils import get_table_resource
from ..utils.dynamodb_utils import ReturnValuesEnum, dynamize, serialize_to_dynamodb
from ..utils.log_utils import logger
from . import base_model_exceptions
from . import dataset_model_exceptions as exceptions
from . import region_singleton_model_exceptions
from .base_model import ValidateEditableAttrsMixin, handle_auth_exceptions
from .region_singleton_model import RegionSingletonFacet

# List of HDMap Services required in order to consider a Dataset.EventsStatus as SUCCESS.
REQUIRED_HDMAP_SERVICE_IDS = (
    ServiceId.MAP_GPKG_EXPORTER.value,
    ServiceId.SPARK_MAP_RASTERIZER.value,
    ServiceId.POSE_GRAPH_VALIDATOR.value,
    ServiceId.ROAD_METRICS.value,
    ServiceId.PCD_TILER.value,
    ServiceId.ICP_MAP_GENERATOR.value,
)


class ServicesStatusEnum(Enum):
    # At least one of the required HDMap Services failed.
    ERROR = "ERROR"
    # All required HDMap Services completed successfully.
    SUCCESS = "SUCCESS"
    # Some of the required HDMap Services has started.
    #  Maybe also some of the non-required.
    SOME_REQUIRED_STARTED = "SOME_REQUIRED_STARTED"
    ALL_REQUIRED_STARTED = "ALL_REQUIRED_STARTED"


class ArtifactsStatusEnum(Enum):
    GRAPH_ONLY = "GRAPH_ONLY"
    SOME_REQUIRED = "SOME_REQUIRED"
    ALL_REQUIRED = "ALL_REQUIRED"


class EnvironmentEnum(Enum):
    PRE_PRODUCTION = "pre-production"
    GEN2_PRODUCTION = "gen2-production"
    IRREGULAR_MAP_CLI = "irregular-map-cli"
    DEV_TEST = "dev-test"


class GsiSessionConst:
    NAME = "GSISession"
    PK_ATTR = "gsi_session_pk_region"
    IS_PK_NULLABLE = False
    PK_BOUND_ATTRS = ("region",)
    SK_ATTR = "gsi_session_sk_session"
    IS_SK_NULLABLE = False
    SK_BOUND_ATTRS = ("session",)
    PROJECTION_TYPE = "KEYS_ONLY"


class GsiDatasetSummaryConst:
    NAME = "GSIDatasetSummary"
    PK_ATTR = "gsi_dataset_summary_pk"
    IS_PK_NULLABLE = False
    PK_BOUND_ATTRS = tuple()
    SK_ATTR = "gsi_dataset_summary_sk_latest_service_run_at"
    IS_SK_NULLABLE = False
    SK_BOUND_ATTRS = ("last_service_run_at",)
    PROJECTION_TYPE = "ALL"


class GsiDatasetSummaryPerEnvConst:
    NAME = "GSIDatasetSummaryPerEnv"
    PK_ATTR = "gsi_dataset_summary_per_env_pk"
    IS_PK_NULLABLE = True
    PK_BOUND_ATTRS = ("environment",)
    SK_ATTR = "gsi_dataset_summary_per_env_sk_latest_service_run_at"
    IS_SK_NULLABLE = False
    SK_BOUND_ATTRS = ("last_service_run_at",)
    PROJECTION_TYPE = "ALL"


class GsiDatasetSummaryPerDrivelogConst:
    NAME = "GSIDatasetSummaryPerDrivelog"
    PK_ATTR = "gsi_dataset_summary_per_drivelog_pk_drivelog"
    IS_PK_NULLABLE = True
    PK_BOUND_ATTRS = ("drivelog",)
    SK_ATTR = "gsi_dataset_summary_per_drivelog_sk_latest_service_run_at"
    IS_SK_NULLABLE = False
    SK_BOUND_ATTRS = ("last_service_run_at",)
    PROJECTION_TYPE = "ALL"


class DatasetItem:
    def __init__(
        self,
        region: str,
        session: str,
        artifacts_status: str = ArtifactsStatusEnum.GRAPH_ONLY.value,
        services_status: str = None,
        # `environment` might be initialized to DEV_TEST in the init method (if the
        #  region name includes "test-" or "-test").
        environment: str = None,
        last_service_run_at: datetime = None,
        pose_graph_bytes: int = None,
        graph_data_files: list = None,
        session_hierarchy: list = None,
        drivelog: str = None,
        operation_type: str = None,
        # DynamoDB doesn't support float attribute type.
        #  See:
        #   - https://github.com/boto/boto3/issues/665
        #   - https://github.com/boto/boto3/issues/369
        # We could also use Decimal but odometer_distance can be `UNKNOWN` so string here is more appropriate.
        odometer_distance: str = None,
        has_gpkg: bool = None,
        has_icp_map_v1: bool = None,
        has_icp_map_v2: bool = None,
        has_non_color_tiles: bool = None,
        has_color_tiles: bool = None,
        has_pcd: bool = None,
        has_road_metrics: bool = None,
        has_bev: bool = None,
        has_colored_point_cloud: bool = None,
        do_send_slack_notification_on_service_status_success: bool = None,
    ):
        # TODO add validation (marshmallow?).
        self.item_type = DatasetFacet.ITEM_TYPE
        self.region = region
        self.session = session
        self.environment = environment
        self.services_status = services_status
        self.artifacts_status = artifacts_status
        self.last_service_run_at = last_service_run_at
        self.pose_graph_bytes = pose_graph_bytes
        self.graph_data_files = graph_data_files
        self.session_hierarchy = session_hierarchy
        self.drivelog = drivelog
        self.operation_type = operation_type
        self.odometer_distance = odometer_distance
        self.has_gpkg = has_gpkg
        self.has_icp_map_v1 = has_icp_map_v1
        self.has_icp_map_v2 = has_icp_map_v2
        self.has_non_color_tiles = has_non_color_tiles
        self.has_color_tiles = has_color_tiles
        self.has_pcd = has_pcd
        self.has_road_metrics = has_road_metrics
        self.has_bev = has_bev
        self.has_colored_point_cloud = has_colored_point_cloud
        self.do_send_slack_notification_on_service_status_success = (
            do_send_slack_notification_on_service_status_success
        )
        self.created_at = None
        self.updated_at = None

        # Rule: if the region name includes the test keyword, set it to DEV_TEST, unless
        #  its given.
        if not self.environment and ("-test" in region or "test-" in region):
            self.environment = EnvironmentEnum.DEV_TEST.value

    @property
    def pk(self) -> str:
        return DatasetFacet.make_pk(self.region, self.session)

    @property
    def sk(self) -> str:
        return DatasetFacet.make_sk(self.region, self.session)

    @property
    def gsi_session_pk_region(self):
        return self.region

    @property
    def gsi_session_sk_session(self):
        return self.session

    @property
    def gsi_dataset_summary_pk(self):
        return "DATASETSUMMARIES"

    @property
    def gsi_dataset_summary_sk_latest_service_run_at(self):
        if not self.last_service_run_at:
            # This is the SK for a non-sparse GSI (needs to include all items),
            #  so we use the string NONE for None values.
            # Also, prepend # (which comes before any number and letter) so that when
            #  retrieving items from DynamoDB in reverse sorting order, it will come last.
            return "#NONE"
        return serialize_to_dynamodb(self.last_service_run_at)

    @property
    def gsi_dataset_summary_per_env_pk(self):
        # This GSI can be sparse (so None values will not be part of the index).
        if self.environment:
            return f"DATASETSUMMARIES#ENV#{self.environment}".upper()

    @property
    def gsi_dataset_summary_per_env_sk_latest_service_run_at(self):
        return self.gsi_dataset_summary_sk_latest_service_run_at

    @property
    def gsi_dataset_summary_per_drivelog_pk_drivelog(self):
        # This GSI can be sparse (so None values will not be part of the index).
        if self.drivelog:
            return f"DATASETSUMMARIES#DRIVELOG#{self.drivelog}".upper()

    @property
    def gsi_dataset_summary_per_drivelog_sk_latest_service_run_at(self):
        return self.gsi_dataset_summary_sk_latest_service_run_at

    @classmethod
    def from_db(cls, data) -> "DatasetItem":
        if data.get("ItemType") != DatasetFacet.ITEM_TYPE:
            raise exceptions.NotADatasetItem

        item = cls(
            region=data.get(dynamize("region")),
            session=data.get(dynamize("session")),
            environment=data.get(dynamize("environment")),
            services_status=data.get(dynamize("services_status")),
            artifacts_status=data.get(dynamize("artifacts_status")),
            pose_graph_bytes=data.get(dynamize("pose_graph_bytes")),
            graph_data_files=data.get(dynamize("graph_data_files")),
            session_hierarchy=data.get(dynamize("session_hierarchy")),
            drivelog=data.get(dynamize("drivelog")),
            operation_type=data.get(dynamize("operation_type")),
            odometer_distance=data.get(dynamize("odometer_distance")),
            has_gpkg=data.get(dynamize("has_gpkg")),
            has_icp_map_v1=data.get(dynamize("has_icp_map_v1")),
            has_icp_map_v2=data.get(dynamize("has_icp_map_v2")),
            has_non_color_tiles=data.get(dynamize("has_non_color_tiles")),
            has_color_tiles=data.get(dynamize("has_color_tiles")),
            has_pcd=data.get(dynamize("has_pcd")),
            has_road_metrics=data.get(dynamize("has_road_metrics")),
            has_bev=data.get(dynamize("has_bev")),
            has_colored_point_cloud=data.get(dynamize("has_colored_point_cloud")),
            do_send_slack_notification_on_service_status_success=data.get(
                dynamize("do_send_slack_notification_on_service_status_success")
            ),
        )
        item.item_type = data.get(dynamize("item_type"))

        last_service_run_at: Optional[str] = data.get(dynamize("last_service_run_at"))
        if last_service_run_at:
            item.last_service_run_at = datetime.fromisoformat(last_service_run_at)

        if item.pose_graph_bytes is not None:  # Check vs None as it can be 0.
            item.pose_graph_bytes = int(item.pose_graph_bytes)

        if item.graph_data_files:
            item.graph_data_files = list(item.graph_data_files)

        if item.session_hierarchy:
            item.session_hierarchy = list(item.session_hierarchy)

        if item.drivelog:
            item.drivelog = str(item.drivelog)

        if item.operation_type:
            item.operation_type = str(item.operation_type)

        if item.odometer_distance:
            item.odometer_distance = str(item.odometer_distance)

        if item.has_gpkg:
            item.has_gpkg = bool(item.has_gpkg)
        if item.has_icp_map_v1:
            item.has_icp_map_v1 = bool(item.has_icp_map_v1)
        if item.has_icp_map_v2:
            item.has_icp_map_v2 = bool(item.has_icp_map_v2)
        if item.has_non_color_tiles:
            item.has_non_color_tiles = bool(item.has_non_color_tiles)
        if item.has_color_tiles:
            item.has_color_tiles = bool(item.has_color_tiles)
        if item.has_pcd:
            item.has_pcd = bool(item.has_pcd)
        if item.has_road_metrics:
            item.has_road_metrics = bool(item.has_road_metrics)
        if item.has_bev:
            item.has_bev = bool(item.has_bev)
        if item.has_colored_point_cloud:
            item.has_colored_point_cloud = bool(item.has_colored_point_cloud)

        if item.do_send_slack_notification_on_service_status_success:
            item.do_send_slack_notification_on_service_status_success = bool(
                item.do_send_slack_notification_on_service_status_success
            )

        item.created_at = data.get(dynamize("created_at"))
        if item.created_at:
            item.created_at = datetime.fromisoformat(item.created_at)

        item.updated_at = data.get(dynamize("updated_at"))
        if item.updated_at:
            item.updated_at = datetime.fromisoformat(item.updated_at)

        return item

    def to_dict(self):
        # TODO this should return all attrs. Maybe make it parametric such that the
        #  views can use it to return only some.
        data = dict()
        for attr in sorted(
            DatasetFacet.ALL_ATTRS_EXCEPT_INDEXES_AND_KEYS - {"item_type"}
        ):
            value = getattr(self, attr)
            data[attr] = serialize_to_dynamodb(value)
        # TODO remove this when we write these timestamps in the right format.
        for attr in ("created_at", "updated_at", "last_service_run_at"):
            if data[attr] and not data[attr].endswith("+00:00"):
                data[attr] += "+00:00"
        return data


class DatasetFacet(ValidateEditableAttrsMixin):
    ITEM_TYPE = "Dataset"

    ALL_INDEXES: set = {
        GsiSessionConst,
        GsiDatasetSummaryConst,
        GsiDatasetSummaryPerEnvConst,
        GsiDatasetSummaryPerDrivelogConst,
    }
    INDEX_KEY_ATTRS: set = {
        *(x.PK_ATTR for x in ALL_INDEXES),
        *(x.SK_ATTR for x in ALL_INDEXES),
    }
    INDEX_KEY_ATTRS_NON_NULLABLE: set = {
        *(x.PK_ATTR for x in ALL_INDEXES if not x.IS_PK_NULLABLE),
        *(x.SK_ATTR for x in ALL_INDEXES if not x.IS_SK_NULLABLE),
    }
    ALL_ATTRS_EXCEPT_INDEXES_AND_KEYS = {
        "region",
        "session",
        "item_type",
        "created_at",
        "updated_at",
        "last_service_run_at",
        "services_status",
        "artifacts_status",
        "environment",
        "pose_graph_bytes",
        "graph_data_files",
        "session_hierarchy",
        "drivelog",
        "operation_type",
        "odometer_distance",
        "has_gpkg",
        "has_icp_map_v1",
        "has_icp_map_v2",
        "has_non_color_tiles",
        "has_color_tiles",
        "has_pcd",
        "has_road_metrics",
        "has_bev",
        "has_colored_point_cloud",
        "do_send_slack_notification_on_service_status_success",
    }
    KEY_ATTRS: set = {"pk", "sk"}
    ALL_ATTRS: set = {
        *ALL_ATTRS_EXCEPT_INDEXES_AND_KEYS,
        *KEY_ATTRS,
        *INDEX_KEY_ATTRS,
    }
    READ_ONLY_ATTRS: set = {
        *KEY_ATTRS,
        "item_type",
        "created_at",
        "updated_at",
        "region",
        "session",
        *INDEX_KEY_ATTRS,
    }
    EDITABLE_ATTRIBUTES: set = ALL_ATTRS - READ_ONLY_ATTRS
    # The min set of attrs required to create a dataset in the DB.
    REQUIRED_ATTRS = {
        "region",
        "session",
        "item_type",
        "created_at",
        "updated_at",
        "artifacts_status",
        *INDEX_KEY_ATTRS_NON_NULLABLE,
    }

    def __init__(self, region: str, session: str):
        self.region = region
        self.session = session

    @staticmethod
    def make_pk(region: str, session: str) -> str:
        return f"DATASET#{region}|{session}"

    @staticmethod
    def make_sk(region: str, session: str) -> str:
        return DatasetFacet.make_pk(region, session)

    @handle_auth_exceptions
    def create(
        self,
        # Use this to avoid updating RegionSingleton.
        do_skip_side_effects=False,
        **attrs_to_create,
    ) -> DatasetItem:
        # Validate attribute names.
        self._validate_editable_attributes(attrs_to_create.keys())

        new_item = DatasetItem(
            region=self.region, session=self.session, **attrs_to_create
        )
        now = time_utils.now()

        # 1st operation (not a transaction): create the Dataset.
        try:
            # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.put_item
            response: PutItemOutputTableTypeDef = get_table_resource().put_item(
                **self.make_put_if_not_existing_expression(new_item, now)
            )
        except get_table_resource().meta.client.exceptions.ConditionalCheckFailedException as exc:
            raise base_model_exceptions.PrimaryKeyConstraintError(new_item) from exc
        logger.debug("Response", extra=dict(response=response))

        new_item.created_at = now
        new_item.updated_at = now

        if do_skip_side_effects:
            return new_item

        # 2nd operation (not a transaction): update RegionSingleton.regions.
        # Not doing this in a transaction because that leads to TransactionConflict
        #  errors when in the S3Bucket Scanner more Lambdas concurrently update
        #  RegionSingleton.regions.
        try:
            RegionSingletonFacet().add_region(self.region)
        except region_singleton_model_exceptions.RegionSingletonRegionsAttrNotAStringSet as exc:
            raise

        return new_item

    @handle_auth_exceptions
    def read(self) -> DatasetItem:
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.get_item
        response: GetItemOutputTableTypeDef = get_table_resource().get_item(
            Key={
                "PK": self.make_pk(self.region, self.session),
                "SK": self.make_sk(self.region, self.session),
            }
        )

        logger.debug("Response", extra=dict(response=response))
        if not response.get("Item"):
            raise base_model_exceptions.ItemNotFound

        item = DatasetItem.from_db(response["Item"])
        return item

    @handle_auth_exceptions
    def delete(self) -> None:
        # TODO Delete Dataset and everything in that PK, like ServiceRuns and
        #  LatestServiceRuns.
        raise NotImplementedError

    @handle_auth_exceptions
    def update(self, **attrs_to_update) -> None:
        # TODO Can we refactor this fn using make_create_or_update_expression()?

        # At least one attr is required when updating.
        if not attrs_to_update:
            raise TypeError("Attributes required")

        # Validate attribute names.
        self._validate_editable_attributes(attrs_to_update.keys())

        ## Prepare the update query params.
        # If we are about to update some attrs more than just `last_service_run_at`:
        #  update also the attr `updated_at`.
        if attrs_to_update and (
            "last_service_run_at" not in attrs_to_update or len(attrs_to_update) > 1
        ):
            update_expression = "SET #updated_at = :updated_at"
        # If we are not updating any attr or just `last_service_run_at`:
        #  do not update the attr `updated_at` unless the attr does not exist.
        else:
            # In case we are creating or updating the Dataset with the objective of updating
            #  the attr LastServiceRunAt, then we don't want to update also the attr
            #  UpdatedAt if existing.
            update_expression = (
                "SET #updated_at = if_not_exists(#updated_at, :updated_at)"
            )
        updated_at = attrs_to_update.get("updated_at") or time_utils.now()
        expression_attribute_names = {"#updated_at": dynamize("updated_at")}
        expression_attribute_values = {":updated_at": serialize_to_dynamodb(updated_at)}

        # Add the attributes to update.
        for key, value in attrs_to_update.items():
            value = serialize_to_dynamodb(value)
            if value is not None:
                update_expression += f", #{key} = :{key}"
                expression_attribute_names[f"#{key}"] = dynamize(key)
                expression_attribute_values[f":{key}"] = value

        # Update GsiDatasetSummary SK, GsiDatasetSummaryPerEnv SK and
        #  GsiDatasetSummaryPerDrivelog SK which are bound to `last_service_run_at`.
        for gsi in (
            GsiDatasetSummaryConst,
            GsiDatasetSummaryPerEnvConst,
            GsiDatasetSummaryPerDrivelogConst,
        ):
            # Note: `last_service_run_at` can be None. But the bound indexes are
            #  not nullable.
            if attrs_to_update and "last_service_run_at" in attrs_to_update:
                sk_attr = gsi.SK_ATTR
                update_expression += f", #{sk_attr} = :{sk_attr}"
                expression_attribute_names[f"#{sk_attr}"] = dynamize(sk_attr)
                # `minted_item` is the item created with the new attrs and the default values.
                # Notice that this is different than the resulting updated item if the item
                #  already exists (because the existing item might have attrs with
                #  non-default values).
                minted_item = DatasetItem(
                    self.region,
                    self.session,
                    last_service_run_at=attrs_to_update["last_service_run_at"],
                )
                expression_attribute_values[f":{sk_attr}"] = getattr(
                    minted_item, sk_attr
                )

        # Update GsiDatasetSummaryPerEnv PK.
        # Note: `environment` can be None. And the bound index PK is nullable.
        if attrs_to_update and attrs_to_update.get("environment"):
            pk_attr = GsiDatasetSummaryPerEnvConst.PK_ATTR
            update_expression += f", #{pk_attr} = :{pk_attr}"
            expression_attribute_names[f"#{pk_attr}"] = dynamize(pk_attr)
            minted_item = DatasetItem(
                self.region, self.session, environment=attrs_to_update["environment"]
            )
            expression_attribute_values[f":{pk_attr}"] = getattr(minted_item, pk_attr)

        # Update GsiDatasetSummaryPerDrivelog PK.
        # Note: `drivelog` can be None. And the bound index PK is nullable.
        if attrs_to_update and attrs_to_update.get("drivelog"):
            pk_attr = GsiDatasetSummaryPerDrivelogConst.PK_ATTR
            update_expression += f", #{pk_attr} = :{pk_attr}"
            expression_attribute_names[f"#{pk_attr}"] = dynamize(pk_attr)
            minted_item = DatasetItem(
                self.region, self.session, drivelog=attrs_to_update["drivelog"]
            )
            expression_attribute_values[f":{pk_attr}"] = getattr(minted_item, pk_attr)

        try:
            # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.update_item
            response: UpdateItemOutputTableTypeDef = get_table_resource().update_item(
                Key={
                    "PK": self.make_pk(self.region, self.session),
                    "SK": self.make_sk(self.region, self.session),
                },
                ConditionExpression=Attr("PK").exists(),
                UpdateExpression=update_expression,
                ExpressionAttributeNames=expression_attribute_names,
                ExpressionAttributeValues=expression_attribute_values,
                ReturnValues="NONE",
            )
        except get_table_resource().meta.client.exceptions.ConditionalCheckFailedException as exc:
            raise base_model_exceptions.ItemNotFound from exc

        logger.debug("Response", extra=dict(response=response))

    @handle_auth_exceptions
    def create_or_update(
        self,
        # Use this to avoid updating RegionSingleton in case of create.
        do_skip_side_effects=False,
        return_values=ReturnValuesEnum.NONE,
        **attrs_to_update,
    ) -> UpdateItemOutputTableTypeDef:
        # Validate attribute names.
        self._validate_editable_attributes(attrs_to_update.keys())

        # 1st operation: create or update the Dataset.
        # Docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb.html#DynamoDB.Table.update_item
        update_item_exp = self.make_create_or_update_expression(
            self.region,
            self.session,
            attrs_to_update=attrs_to_update,
            return_values=return_values,
        )
        response: UpdateItemOutputTableTypeDef = get_table_resource().update_item(
            **update_item_exp
        )
        logger.debug("Response", extra=dict(response=response))

        if do_skip_side_effects:
            return

        # 2nd operation (not a transaction): update RegionSingleton.regions.
        # Not doing this in a transaction because that leads to TransactionConflict
        #  errors when in the S3Bucket Scanner more Lambdas concurrently update
        #  RegionSingleton.regions.
        try:
            RegionSingletonFacet().add_region(self.region)
        except region_singleton_model_exceptions.RegionSingletonRegionsAttrNotAStringSet as exc:
            raise

        return response

    @classmethod
    def make_put_if_not_existing_expression(
        cls, new_item: DatasetItem, now: Optional[datetime] = None
    ) -> dict:
        """
        Make a dictionary that represents an expression to be used with put_item() to create Dataset.
        """
        if not now:
            now = time_utils.now()

        last_service_run_at: Optional[str] = None
        if new_item.last_service_run_at:
            last_service_run_at = serialize_to_dynamodb(new_item.last_service_run_at)

        expression = {
            "Item": {
                "PK": new_item.pk,
                "SK": new_item.sk,
                # TODO refactor this using a for loop on ALL_ATTRS or similar (plus dynamize).
                dynamize("item_type"): new_item.item_type,
                dynamize("region"): new_item.region,
                dynamize("session"): new_item.session,
                dynamize("services_status"): new_item.services_status,
                dynamize("artifacts_status"): new_item.artifacts_status,
                dynamize("environment"): new_item.environment,
                dynamize("created_at"): serialize_to_dynamodb(now),
                dynamize("updated_at"): serialize_to_dynamodb(now),
                dynamize("pose_graph_bytes"): new_item.pose_graph_bytes,
                dynamize("graph_data_files"): new_item.graph_data_files,
                dynamize("session_hierarchy"): new_item.session_hierarchy,
                dynamize("drivelog"): new_item.drivelog,
                dynamize("operation_type"): new_item.operation_type,
                dynamize("odometer_distance"): new_item.odometer_distance,
                dynamize("has_gpkg"): new_item.has_gpkg,
                dynamize("has_icp_map_v1"): new_item.has_icp_map_v1,
                dynamize("has_icp_map_v2"): new_item.has_icp_map_v2,
                dynamize("has_non_color_tiles"): new_item.has_non_color_tiles,
                dynamize("has_color_tiles"): new_item.has_color_tiles,
                dynamize("has_pcd"): new_item.has_pcd,
                dynamize("has_road_metrics"): new_item.has_road_metrics,
                dynamize("has_bev"): new_item.has_bev,
                dynamize("has_colored_point_cloud"): new_item.has_colored_point_cloud,
                dynamize(
                    "do_send_slack_notification_on_service_status_success"
                ): new_item.do_send_slack_notification_on_service_status_success,
                dynamize("last_service_run_at"): last_service_run_at,
                dynamize("gsi_session_pk_region"): new_item.gsi_session_pk_region,
                dynamize("gsi_session_sk_session"): new_item.gsi_session_sk_session,
                dynamize("gsi_dataset_summary_pk"): new_item.gsi_dataset_summary_pk,
                dynamize(
                    "gsi_dataset_summary_sk_latest_service_run_at"
                ): new_item.gsi_dataset_summary_sk_latest_service_run_at,
                dynamize(
                    "gsi_dataset_summary_per_env_pk"
                ): new_item.gsi_dataset_summary_per_env_pk,
                dynamize(
                    "gsi_dataset_summary_per_env_sk_latest_service_run_at"
                ): new_item.gsi_dataset_summary_per_env_sk_latest_service_run_at,
                dynamize(
                    "gsi_dataset_summary_per_drivelog_pk_drivelog"
                ): new_item.gsi_dataset_summary_per_drivelog_pk_drivelog,
                dynamize(
                    "gsi_dataset_summary_per_drivelog_sk_latest_service_run_at"
                ): new_item.gsi_dataset_summary_per_drivelog_sk_latest_service_run_at,
            },
            # Do not overwrite.
            # Do not use `Attr("PK").not_exists()` as it does not work with transact_write_items().
            "ConditionExpression": "attribute_not_exists(PK)",
        }

        # Remove the None values.
        for key, value in {**expression["Item"]}.items():
            if value is None:
                del expression["Item"][key]
        return expression

    @classmethod
    def make_create_or_update_expression(
        cls,
        region: str,
        session: str,
        attrs_to_update: Optional[dict] = None,
        is_transaction: bool = False,
        return_values=ReturnValuesEnum.NONE,
    ) -> dict:
        """
        Make an expression to be used with update_item() or transact_write_items()
        to create or update a Dataset.

        Args:
            region: Dataset region name.
            session: Dataset session name.
            attrs_to_update: dictionary with names and values of attributes to update.
            is_transaction: true if this expression will be part of a transaction.

        Returns [dict]:
            # If not is_transaction:
            {
                "Key": {
                    "PK": "pk1",
                    "SK": "sk1",
                },
                "UpdateExpression": "
                    SET #region = if_not_exists(#region, :region),
                    #drivelog = :drivelog,
                    #gsi_session_pk_region = if_not_exists(#gsi_session_pk_region, :gsi_session_pk_region)
                ",

                "ExpressionAttributeNames": {
                    "#region": "Region",
                    "#drivelog": "Drivelog",
                    "#gsi_session_pk_region": "GSISessionPKRegion",
                }

                "ExpressionAttributeValues": {
                    ":region": "sg-one-north",
                    ":drivelog": "2022.06.23.16.51.09_g2h-veh-8006",
                    ":gsi_session_pk_region": "sg-one-north",
                },

                "ReturnValues": "NONE",

                # Comment this out because the Dataset might already exist (update case).
                # ConditionExpression="attribute_exists(PK)",
            }

            # If is_transaction:
            {
                "Update": {
                    "TableName": "MyTable",

                    ↑↑ SAME DICT ITEMS AS CASE NO TRANSACTION (see above) ↑↑
                          (minus the key ReturnValues)

                    "ReturnValuesOnConditionCheckFailure": "NONE",
                }
            }
        """
        # Note that `attrs_to_update` is optional because this method can just be used
        #  to create a Dataset with default attrs (and that it might already exist).
        attrs_to_update = attrs_to_update or dict()

        # Validate attribute names.
        cls._validate_editable_attributes(attrs_to_update.keys())

        # `minted_item` is the item created with the new attrs and the default values.
        # Notice that this is different than the resulting updated item if the item
        #  already exists (because the existing item might have attrs with
        #  non-default values).
        minted_item = DatasetItem(region=region, session=session, **attrs_to_update)

        factory = dynamodb_utils.UpdateExpressionFactory(minted_item.pk, minted_item.sk)

        # Add all attributes (minus pk, sk, and indexes) to update but be skipped if existing.
        for attr_name in cls.ALL_ATTRS_EXCEPT_INDEXES_AND_KEYS:
            attr_value = getattr(minted_item, attr_name)
            if attr_value is not None:
                attr_value = serialize_to_dynamodb(attr_value)
                factory.add_attr(attr_name, attr_value, do_skip_if_existing=True)

        # Add all attributes to (forcibly) update.
        for attr_name, attr_value in attrs_to_update.items():
            if attr_value is not None:
                attr_value = serialize_to_dynamodb(attr_value)
                factory.add_attr(attr_name, attr_value, do_skip_if_existing=False)

        # Add all indexes.
        for gsi in cls.ALL_INDEXES:
            pk_value = getattr(minted_item, gsi.PK_ATTR)
            sk_value = getattr(minted_item, gsi.SK_ATTR)
            # Ensure the values are not None if they shouldn't be.
            if pk_value is None and not gsi.IS_PK_NULLABLE:
                raise base_model_exceptions.NotNullableGsi(
                    f"Cannot set GSI indexed attr to None: {gsi.NAME}.{gsi.PK_ATTR}"
                )
            if sk_value is None and not gsi.IS_SK_NULLABLE:
                raise base_model_exceptions.NotNullableGsi(
                    f"Cannot set GSI indexed attr to None: {gsi.NAME}.{gsi.SK_ATTR}"
                )
            # Write their values.
            if pk_value:
                # The attribute is not updated if it exists already.
                do_skip_if_existing = True
                for x in gsi.PK_BOUND_ATTRS:
                    if x in attrs_to_update:
                        do_skip_if_existing = False
                pk_value = serialize_to_dynamodb(pk_value)
                factory.add_attr(
                    gsi.PK_ATTR, pk_value, do_skip_if_existing=do_skip_if_existing
                )
            if sk_value:
                # The attribute is not updated if it exists already.
                do_skip_if_existing = True
                for x in gsi.SK_BOUND_ATTRS:
                    if x in attrs_to_update:
                        do_skip_if_existing = False
                sk_value = serialize_to_dynamodb(sk_value)
                factory.add_attr(
                    gsi.SK_ATTR, sk_value, do_skip_if_existing=do_skip_if_existing
                )

        # Special case `created_at`.
        now = time_utils.now()
        factory.add_attr(
            "created_at", serialize_to_dynamodb(now), do_skip_if_existing=True
        )

        # Special case `updated_at`: if we are about to update some attrs more than
        #  just `last_service_run_at` then update also the attr `updated_at`.
        do_skip_updated_at = False
        if not attrs_to_update or (
            len(attrs_to_update) == 1 and "last_service_run_at" in attrs_to_update
        ):
            # There is no attrs_to_update.
            do_skip_updated_at = True
        factory.add_attr(
            "updated_at",
            serialize_to_dynamodb(now),
            do_skip_if_existing=do_skip_updated_at,
        )

        kwargs = dict()
        if is_transaction:
            kwargs = dict(is_transaction=True, table_name=settings.DYNAMODB_TABLE_NAME)
        exp = factory.make(return_values=return_values, **kwargs)
        return exp
