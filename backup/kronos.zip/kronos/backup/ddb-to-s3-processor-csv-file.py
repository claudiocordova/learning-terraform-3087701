import os
import json
import boto3
import csv

def lambda_handler(event, context):
    # Get the DynamoDB stream records from the event
    records = event['Records']

    # Create an empty list to store the JSON data
    data = []

    # Iterate over the records and extract the JSON data
    for record in records:
        # Get the new or updated item from the stream record
        item = record.get('dynamodb').get('NewImage') or record.get('dynamodb').get('OldImage')
        
        # Convert the DynamoDB JSON item to a Python dictionary
        item_dict = {k: v.get(list(v.keys())[0]) for k, v in item.items()}

        # Append the dictionary to the data list
        data.append(item_dict)

    # Create a CSV file
    csv_file = '/tmp/data.csv'

    # Write the data to the CSV file
    with open(csv_file, 'w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=data[0].keys())
        writer.writeheader()
        writer.writerows(data)

    # Upload the CSV file to S3
    s3_bucket = os.environ['S3_BUCKET']
    s3_key = os.environ['S3_KEY']
    s3_client = boto3.client('s3')
    s3_client.upload_file(csv_file, s3_bucket, s3_key)

    return {
        'statusCode': 200,
        'body': 'CSV data converted and uploaded to S3'
    }
