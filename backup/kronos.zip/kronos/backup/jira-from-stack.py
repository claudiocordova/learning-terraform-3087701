import requests
import urllib3
import math


url = 'https://mydomain.atlassian.net/rest/api/2/search'

headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Basic 012336',
    'Postman-Token': "0123456789"
}

parameters = {
    'jql': 'project IN (A, B, C, D, E, F, G, H, I, J, K, L, M) AND issueType=incident AND statusCategory!=Done',
    'startAt': 0,
    'maxResults': 50,
    'fields': "key,status,project,priority,issuetype,created,statuscategory"
}

response = requests.request("GET", url, headers=headers, params=parameters)
jira_data = response.json()
jira_pretty = json.dumps(json.loads(response.text), sort_keys=True, indent=4)
int_total = jira_data.get('total')
int_maxResults = jira_data.get('maxResults')
int_startAt = parameters.get('startAt')
number_pages = math.ceil(int(int_total)/int(int_maxResults))

while int_startAt < int_total:
    int_startAt += int_maxResults
    if int_total <= int_startAt:
        break

print(jira_pretty)
