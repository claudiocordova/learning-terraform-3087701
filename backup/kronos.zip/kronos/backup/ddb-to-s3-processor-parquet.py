# In this code, we assume that you have set up an S3 bucket where
# you want to store the Parquet data. You need to provide the bucket name
# and the desired key in the lambda environment variables as S3_BUCKET and S3_KEY,
# respectively.
# The function takes the DynamoDB stream event as input (event) and iterates
# over the records in the stream. It extracts the JSON data from each record
# and appends it to a pandas DataFrame. Finally, it converts the DataFrame
# to the Parquet format and uploads the resulting data to the specified S3 bucket.

import os
import json
import boto3
import pandas as pd


def lambda_handler(event, context):
    # Get the DynamoDB stream records from the event
    records = event["Records"]

    # Create an empty DataFrame to store the JSON data
    df = pd.DataFrame()

    # Iterate over the records and extract the JSON data
    for record in records:
        # Get the new or updated item from the stream record
        item = record.get("dynamodb").get("NewImage") or record.get("dynamodb").get(
            "OldImage"
        )

        # Convert the DynamoDB JSON item to a Python dictionary
        item_dict = {k: v.get(list(v.keys())[0]) for k, v in item.items()}

        # Append the dictionary to the DataFrame
        df = df.append(item_dict, ignore_index=True)

    # Convert DataFrame to Parquet format
    parquet_data = df.to_parquet()

    # Upload the Parquet data to S3
    s3_bucket = os.environ["S3_BUCKET"]
    s3_key = os.environ["S3_KEY"]
    s3_client = boto3.client("s3")
    s3_client.put_object(Body=parquet_data, Bucket=s3_bucket, Key=s3_key)

    return {"statusCode": 200, "body": "Parquet data converted and uploaded to S3"}
