# import the installed Jira library
from jira import JIRA
  
# Specify a server key. It should be your
# domain name link. yourdomainname.atlassian.net
jiraOptions = {'server': "https://jira.ci.motional.com/atljira/rest/api/2/search"}
  
# Get a JIRA client instance, pass,
# Authentication parameters
# and the Server name.
# emailID = your emailID
# token = token you receive after registration
jira = JIRA(options=jiraOptions , basic_auth=(
    "claudio.cordova@motional.com", "NjUzMzUyMzg4NDI5OjY3kza/AgHzVeg/iwWmIA9PkfcB"))
  
# Search all issues mentioned against a project name.
for singleIssue in jira.search_issues(jql_str='key = MAPBUILD-4681'):
#for singleIssue in jira.search_issues(jql_str='project = MAPBUILD'):
    print('{}: {}:{}'.format(singleIssue.key, singleIssue.fields.summary,
                             singleIssue.fields.reporter.displayName))



# While fetching details of a single issue,
# pass its UniqueID or Key.
singleIssue = jira.issue('MAP-2304')
print('{}: {}:{}'.format(singleIssue.key,
                         singleIssue.fields.summary,
                         singleIssue.fields.reporter.displayName))


#NjUzMzUyMzg4NDI5OjY3kza/AgHzVeg/iwWmIA9PkfcB





