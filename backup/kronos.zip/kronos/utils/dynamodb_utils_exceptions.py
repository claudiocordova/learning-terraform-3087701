class BaseUpdateExpressionFactoryException(Exception):
    pass


class NoAttrsAdded(BaseUpdateExpressionFactoryException):
    pass


class AttributeValuesConflict(BaseUpdateExpressionFactoryException):
    pass


class IndexValueNoneError(BaseUpdateExpressionFactoryException):
    pass


class BasePaginationError(Exception):
    pass


class PaginationConfigError(BasePaginationError):
    pass


class StartingTokenPaginationConfigError(BasePaginationError):
    pass
