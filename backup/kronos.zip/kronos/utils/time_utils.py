from datetime import datetime

from ..conf import settings


def now() -> datetime:
    if settings.FROZEN_TIME:
        return settings.FROZEN_TIME
    return datetime.utcnow()
