import log_adapter as logger
from kronos.__version__ import __version__

# Configure the logging only once.
_IS_CONFIGURED = False


def configure():
    global _IS_CONFIGURED
    if _IS_CONFIGURED:
        return
    # This project uses the lib `events` which requires the lib
    #  `log-adapter` to perform logging, configured to use Lambda Powertools.
    powertools_logger = logger.PowertoolsLoggerAdapter()
    powertools_logger.configure_default(
        service_name=f"Kronos",
        service_version=__version__,
        is_verbose=False,
    )
    logger.set_adapter(powertools_logger)
    _IS_CONFIGURED = True
