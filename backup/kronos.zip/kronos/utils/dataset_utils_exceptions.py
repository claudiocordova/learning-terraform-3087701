class BaseNewRegionValidationError(Exception):
    pass


class InvalidRegionName(BaseNewRegionValidationError):
    def __init__(self, name):
        self.name = name


class BaseNewSessionValidationError(Exception):
    pass


class InvalidSessionName(BaseNewSessionValidationError):
    def __init__(self, name):
        self.name = name
