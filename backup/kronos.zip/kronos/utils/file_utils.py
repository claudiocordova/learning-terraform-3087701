KB = 1024
MB = KB * KB


def _round_size(size, factor, min_digits=1, max_digits=6) -> float:
    pretty_size = round(size / factor, min_digits)
    if not pretty_size > 0:
        pretty_size = round(size / factor, max_digits)
    return pretty_size


def round_bytes_to_mbytes(size, min_digits=1, max_digits=6) -> float:
    return _round_size(size, MB, min_digits, max_digits)


def round_mbytes_to_gbytes(size, min_digits=1, max_digits=9) -> float:
    return _round_size(size, KB, min_digits, max_digits)
