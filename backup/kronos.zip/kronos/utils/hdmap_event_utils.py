from aws_lambda_powertools.utilities.data_classes import SNSEvent
from events.hdmap_services_events import ServiceStartEvent, ServiceStopEvent
from events.hdmap_services_events import exceptions as hdmap_services_events_exceptions
from ..domains import service_run_domain_exceptions as exceptions
from typing import Any, Dict, Union

def convert_to_hdmap_service_event(raw_incoming_event: Dict[str, Any]) -> Union[ServiceStartEvent, ServiceStopEvent]:
    sns_event = SNSEvent(raw_incoming_event)
    hdmap_service_event = parse_hdmap_service_event(sns_event)
    #self.hdmap_service_event = self._parse_hdmap_service_event_single_record()
    print("hdmap_event_utils: " + str(type(hdmap_service_event)))
    print("hdmap_event_utils: " + str(hdmap_service_event))
    return hdmap_service_event


def parse_hdmap_service_event(sns_event) -> Union[ServiceStartEvent, ServiceStopEvent]:
    # Try to make a service START event. If it fails validation then try to make
    #  a service STOP event.
    try:
        return ServiceStartEvent.make_from_raw_event_json(
            sns_event.sns_message
        )
    except hdmap_services_events_exceptions.ValidationError:
        pass

    try:
        return ServiceStopEvent.make_from_raw_event_json(sns_event.sns_message)
    except hdmap_services_events_exceptions.ValidationError:
        pass

    raise exceptions.IncomingEventUnknown(sns_event=sns_event)    