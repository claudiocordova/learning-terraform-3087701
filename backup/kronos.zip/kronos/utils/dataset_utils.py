import re
from datetime import datetime
from typing import Optional

from ..conf import settings

from . import dataset_utils_exceptions as exceptions

KNOWN_LEGACY_DATASETS = (("sg-cetran", "2019-05-03_144755-001"),)


def validate_region_name(name: Optional[str]) -> None:
    # Allowed chars are lowercase letters, numbers and dashes.
    pattern = r"^[a-z]{1}[a-z0-9-]+$"
    if not name or not bool(re.match(pattern, name)):
        raise exceptions.InvalidRegionName(name)


def validate_session_name(name: Optional[str]) -> None:
    # In test only consider the first 23 chars, to allow a random part.
    if name and settings.IS_TEST:
        name = name[:23]
    # Format YYYY-mm-dd_HH-MM-SS-GMT.
    try:
        datetime.strptime(name, "%Y-%m-%d_%H-%M-%S-GMT")
    except (TypeError, ValueError):
        raise exceptions.InvalidSessionName(name)


def is_known_legacy_dataset(region: str, session: str):
    return (region, session) in KNOWN_LEGACY_DATASETS
