# Do not edit __version__ directly, instead run: `$ make version-bump/1.0.0`.
__version__ = "1.0.0"
